# Wrapper-Based Feature Selection Summary

Wrapper method:    StepUp
Wrapper model:     Linear
Redundancy-aware:  True

## Selected Features

['number_of_reviews', 'availability_365']

## Selection Scores (Mean Absolute Error: Lower = More important)

| feature           |      score |
|:------------------|-----------:|
| number_of_reviews | -2.433e-01 |
| availability_365  | -2.417e-01 |

# Redundant Stepwise Selection Results

Metric: MAE

* number_of_reviews (MAE=-0.24329) - [Iteration   0]
* availability_365 (MAE=-0.24169) - [Iteration   1]

redundants                        score
------------------------------  -------
oheencoded_Staten_Island_1.0    -0.2433
oheencoded_Manhattan_1.0        -0.2433
oheencoded_Brooklyn_1.0         -0.2433
longitude                       -0.2433
city                            -0.2433
oheencoded_Bronx_1.0            -0.2433
oheencoded_Queens_1.0           -0.2433
hotel_1.0                       -0.2433
oheencoded_Hotel_room_1.0       -0.2433
oheencoded_Shared_room_nan      -0.2433
oheencoded_Staten_Island_nan    -0.2433
oheencoded_Shared_room_1.0      -0.2433
private                         -0.2433
oheencoded_Brooklyn_nan         -0.2433
floor                           -0.2433
oheencoded_Entire_home/apt_1.0  -0.2433
hotel_nan                       -0.2433
cozy                            -0.2433
in                              -0.2433
oheencoded_Queens_nan           -0.2433
latitude                        -0.2433
oheencoded_Manhattan_nan        -0.2433
oheencoded_Hotel_room_nan       -0.2433
oheencoded_Entire_home/apt_nan  -0.2433
oheencoded_Bronx_nan            -0.2433
oheencoded_Private_room_1.0     -0.2433
luxury                          -0.2433
room                            -0.2433
oheencoded_Private_room_nan     -0.2433
neighbourhood_labelencoded      -0.2431
price                           -0.2430
availability_365                -0.2417

