# Filter-Based Feature Selection Summary


## Selected Features

['number_of_reviews', 'availability_365', 'longitude', 'price', 'city', 'neighbourhood_labelencoded', 'private', 'oheencoded_Manhattan', 'oheencoded_Bronx', 'oheencoded_Queens', 'oheencoded_Brooklyn', 'oheencoded_Shared_room']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| number_of_reviews          | 5.038e-03 |
| availability_365           | 8.946e-03 |
| longitude                  | 1.047e-02 |
| price                      | 1.048e-02 |
| city                       | 1.065e-02 |
| neighbourhood_labelencoded | 1.077e-02 |
| private                    | 1.079e-02 |
| floor                      | 1.082e-02 |
| room                       | 1.082e-02 |
| cozy                       | 1.083e-02 |
| in                         | 1.085e-02 |
| luxury                     | 1.087e-02 |
| latitude                   | 1.094e-02 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| oheencoded_Manhattan       | 7.867e-03 |
| oheencoded_Bronx           | 1.043e-02 |
| oheencoded_Queens          | 1.046e-02 |
| oheencoded_Brooklyn        | 1.053e-02 |
| oheencoded_Shared_room     | 1.060e-02 |
| oheencoded_Hotel_room      | 1.061e-02 |
| oheencoded_Private_room    | 1.066e-02 |
| oheencoded_Entire_home/apt | 1.068e-02 |
| hotel                      | 1.072e-02 |
| oheencoded_Staten_Island   | 1.086e-02 |