# Filter-Based Feature Selection Summary


## Selected Features

['availability_365', 'longitude', 'number_of_reviews', 'price', 'neighbourhood_labelencoded', 'latitude', 'luxury', 'floor', 'city', 'room', 'private', 'in', 'cozy', 'oheencoded_Manhattan', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Bronx', 'oheencoded_Brooklyn', 'oheencoded_Queens', 'hotel', 'oheencoded_Staten_Island', 'oheencoded_Shared_room', 'oheencoded_Hotel_room']

## Selection Association Scores 

### Continuous Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| availability_365           |  1.230e-01 |
| longitude                  |  9.002e-02 |
| number_of_reviews          |  8.767e-02 |
| price                      |  8.675e-02 |
| neighbourhood_labelencoded |  8.183e-02 |
| latitude                   |  8.179e-02 |
| luxury                     |  1.359e-02 |
| floor                      |  5.949e-03 |
| city                       |  5.766e-03 |
| room                       |  4.523e-03 |
| private                    |  2.295e-03 |
| in                         |  0.000e+00 |
| cozy                       |  0.000e+00 |

### Categorical Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| oheencoded_Manhattan       |  2.126e-02 |
| oheencoded_Entire_home/apt |  1.328e-02 |
| oheencoded_Private_room    |  1.091e-02 |
| oheencoded_Bronx           |  6.525e-03 |
| oheencoded_Brooklyn        |  6.454e-03 |
| oheencoded_Queens          |  4.818e-03 |
| hotel                      |  2.425e-03 |
| oheencoded_Staten_Island   |  6.882e-04 |
| oheencoded_Shared_room     |  3.710e-04 |
| oheencoded_Hotel_room      |  4.293e-05 |