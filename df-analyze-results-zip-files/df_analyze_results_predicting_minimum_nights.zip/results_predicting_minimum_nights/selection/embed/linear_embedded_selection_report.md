# Wrapper-Based Feature Selection Summary

Wrapper model:  Linear

## Selected Features

['latitude', 'longitude', 'price', 'number_of_reviews', 'availability_365', 'neighbourhood_labelencoded', 'luxury', 'floor', 'city', 'private', 'in', 'cozy', 'room', 'hotel_1.0', 'oheencoded_Bronx_1.0', 'oheencoded_Brooklyn_1.0', 'oheencoded_Entire_home/apt_1.0', 'oheencoded_Hotel_room_1.0', 'oheencoded_Manhattan_1.0', 'oheencoded_Private_room_1.0', 'oheencoded_Queens_1.0', 'oheencoded_Staten_Island_1.0']

## Selection scores (Coefficients: Larger magnitude = More important)

| feature                        |      score |
|:-------------------------------|-----------:|
| latitude                       |  5.455e-04 |
| longitude                      | -1.186e-04 |
| price                          |  4.993e-04 |
| number_of_reviews              | -1.414e-03 |
| availability_365               |  5.781e-04 |
| neighbourhood_labelencoded     | -8.276e-04 |
| luxury                         | -4.913e-05 |
| floor                          |  1.707e-04 |
| city                           |  2.178e-04 |
| private                        | -3.849e-04 |
| in                             | -4.054e-03 |
| cozy                           | -1.566e-03 |
| room                           |  1.195e-03 |
| hotel_1.0                      |  2.981e-04 |
| hotel_nan                      |  0.000e+00 |
| oheencoded_Bronx_1.0           | -3.368e-03 |
| oheencoded_Bronx_nan           |  0.000e+00 |
| oheencoded_Brooklyn_1.0        | -3.376e-03 |
| oheencoded_Brooklyn_nan        |  0.000e+00 |
| oheencoded_Entire_home/apt_1.0 | -2.164e-03 |
| oheencoded_Entire_home/apt_nan |  0.000e+00 |
| oheencoded_Hotel_room_1.0      | -2.668e-05 |
| oheencoded_Hotel_room_nan      |  0.000e+00 |
| oheencoded_Manhattan_1.0       |  1.848e-02 |
| oheencoded_Manhattan_nan       |  0.000e+00 |
| oheencoded_Private_room_1.0    |  1.999e-03 |
| oheencoded_Private_room_nan    |  0.000e+00 |
| oheencoded_Queens_1.0          | -5.335e-03 |
| oheencoded_Queens_nan          |  0.000e+00 |
| oheencoded_Shared_room_1.0     | -4.955e-06 |
| oheencoded_Shared_room_nan     |  0.000e+00 |
| oheencoded_Staten_Island_1.0   |  3.012e-04 |
| oheencoded_Staten_Island_nan   |  0.000e+00 |