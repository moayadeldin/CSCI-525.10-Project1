# Wrapper-Based Feature Selection Summary

Wrapper model:  LGBM

## Selected Features

['latitude', 'longitude', 'price', 'number_of_reviews', 'availability_365', 'neighbourhood_labelencoded']

## Selection scores (Importances: Larger magnitude = More important)

| feature                        |     score |
|:-------------------------------|----------:|
| latitude                       | 1.096e+03 |
| longitude                      | 1.224e+03 |
| price                          | 1.223e+03 |
| number_of_reviews              | 7.350e+02 |
| availability_365               | 8.110e+02 |
| neighbourhood_labelencoded     | 5.680e+02 |
| luxury                         | 1.100e+01 |
| floor                          | 3.000e+00 |
| city                           | 5.000e+00 |
| private                        | 2.700e+01 |
| in                             | 1.110e+02 |
| cozy                           | 1.700e+01 |
| room                           | 4.000e+01 |
| hotel_1.0                      | 0.000e+00 |
| hotel_nan                      | 0.000e+00 |
| oheencoded_Bronx_1.0           | 9.000e+00 |
| oheencoded_Bronx_nan           | 0.000e+00 |
| oheencoded_Brooklyn_1.0        | 3.500e+01 |
| oheencoded_Brooklyn_nan        | 0.000e+00 |
| oheencoded_Entire_home/apt_1.0 | 1.010e+02 |
| oheencoded_Entire_home/apt_nan | 0.000e+00 |
| oheencoded_Hotel_room_1.0      | 0.000e+00 |
| oheencoded_Hotel_room_nan      | 0.000e+00 |
| oheencoded_Manhattan_1.0       | 4.100e+01 |
| oheencoded_Manhattan_nan       | 0.000e+00 |
| oheencoded_Private_room_1.0    | 6.000e+01 |
| oheencoded_Private_room_nan    | 0.000e+00 |
| oheencoded_Queens_1.0          | 1.700e+01 |
| oheencoded_Queens_nan          | 0.000e+00 |
| oheencoded_Shared_room_1.0     | 1.400e+01 |
| oheencoded_Shared_room_nan     | 0.000e+00 |
| oheencoded_Staten_Island_1.0   | 0.000e+00 |
| oheencoded_Staten_Island_nan   | 0.000e+00 |