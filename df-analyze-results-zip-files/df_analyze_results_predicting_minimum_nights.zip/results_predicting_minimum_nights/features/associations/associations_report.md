# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |      F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|-------:|---------:|
| availability_365           |    0.123   |     -0.0438 |    2.14e-10 |     -0.194   |     0        |  40.4  | 2.14e-10 |
| longitude                  |    0.09    |     -0.0852 |    0        |     -0.157   |     0        | 154    | 0        |
| number_of_reviews          |    0.0877  |     -0.152  |    0        |     -0.384   |     0        | 496    | 0        |
| price                      |    0.0867  |     -0.0666 |    0        |     -0.172   |     0        |  93.6  | 0        |
| neighbourhood_labelencoded |    0.0818  |      0.0291 |    2.48e-05 |      0.0689  |     0        |  17.8  | 2.48e-05 |
| latitude                   |    0.0818  |      0.0414 |    2.03e-09 |      0.102   |     0        |  36    | 2.03e-09 |
| luxury                     |    0.0136  |      0      |    0        |      0       |     0        |   0    | 1        |
| floor                      |    0.00595 |      0      |    0        |      0       |     0        |   0    | 1        |
| city                       |    0.00577 |      0      |    0        |      0       |     0        |   0    | 1        |
| room                       |    0.00452 |      0.0381 |    3.35e-08 |      0.0479  |     0        |  30.5  | 3.35e-08 |
| private                    |    0.00229 |     -0.0121 |    0.0789   |     -0.0188  |     0.00644  |   3.09 | 0.0789   |
| in                         |    0       |     -0.0177 |    0.0102   |     -0.00257 |     0.709    |   6.61 | 0.0102   |
| cozy                       |    0       |     -0.0273 |    7.87e-05 |     -0.0378  |     4.18e-08 |  15.6  | 7.87e-05 |

# Categorical associations

|                            |   mut_info |        H |   H_p |
|:---------------------------|-----------:|---------:|------:|
| oheencoded_Manhattan       |   0.0213   | 1.46e+04 |     0 |
| oheencoded_Entire_home/apt |   0.0133   | 1.89e+04 |     0 |
| oheencoded_Private_room    |   0.0109   | 1.4e+04  |     0 |
| oheencoded_Bronx           |   0.00653  | 8.28e+03 |     0 |
| oheencoded_Brooklyn        |   0.00645  | 1.42e+04 |     0 |
| oheencoded_Queens          |   0.00482  | 9.79e+03 |     0 |
| hotel                      |   0.00243  | 7.92e+03 |     0 |
| oheencoded_Staten_Island   |   0.000688 | 7.98e+03 |     0 |
| oheencoded_Shared_room     |   0.000371 | 8.02e+03 |     0 |
| oheencoded_Hotel_room      |   4.29e-05 | 7.88e+03 |     0 |

**Note**: values less than 1e-10 are rounded to zero.
