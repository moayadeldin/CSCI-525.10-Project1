# Continuous predictions

| feature                    | model      |    mae |   msqe |     mdae |       r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|---------:|---------:|-----------:|
| number_of_reviews          | sgd-linear | 0.2329 | 0.1511 | 0.132    |  0.02831 |  0.04119   |
| availability_365           | sgd-linear | 0.2368 | 0.1613 | 0.1028   | -0.05095 |  0.003547  |
| longitude                  | sgd-linear | 0.2384 | 0.1618 | 0.07799  | -0.05604 |  0.001716  |
| price                      | sgd-linear | 0.2384 | 0.1621 | 0.07524  | -0.05769 |  0.001167  |
| neighbourhood_labelencoded | sgd-linear | 0.2387 | 0.1625 | 0.07955  | -0.0619  |  0.0003104 |
| private                    | sgd-linear | 0.2387 | 0.1623 | 0.07477  | -0.05963 |  0.0002218 |
| cozy                       | sgd-linear | 0.2387 | 0.1623 | 0.07358  | -0.05942 |  1.802e-05 |
| city                       | sgd-linear | 0.2385 | 0.1624 | 0.0724   | -0.06108 |  2.22e-17  |
| price                      | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| latitude                   | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| room                       | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| availability_365           | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| longitude                  | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| number_of_reviews          | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| city                       | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| floor                      | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| luxury                     | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| neighbourhood_labelencoded | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| in                         | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| cozy                       | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| private                    | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| luxury                     | sgd-linear | 0.2388 | 0.1623 | 0.07343  | -0.05981 | -2.22e-17  |
| floor                      | sgd-linear | 0.2387 | 0.1622 | 0.07339  | -0.0591  | -4.441e-17 |
| room                       | sgd-linear | 0.2387 | 0.1623 | 0.07374  | -0.06015 | -5.479e-05 |
| in                         | sgd-linear | 0.2387 | 0.1623 | 0.07401  | -0.05988 | -9.447e-05 |
| latitude                   | sgd-linear | 0.2388 | 0.1625 | 0.07679  | -0.06106 | -0.000772  |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |     mdae |       r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|---------:|---------:|-----------:|
| oheencoded_Manhattan       | sgd-linear | 0.2358 | 0.1603 | 0.09445  | -0.04461 |  0.01209   |
| oheencoded_Brooklyn        | sgd-linear | 0.2384 | 0.1621 | 0.07915  | -0.05874 |  0.001342  |
| oheencoded_Queens          | sgd-linear | 0.2384 | 0.1624 | 0.07912  | -0.06075 |  0.0004961 |
| oheencoded_Bronx           | sgd-linear | 0.2383 | 0.1625 | 0.0712   | -0.06165 |  0.0003575 |
| oheencoded_Hotel_room      | sgd-linear | 0.2385 | 0.1624 | 0.07253  | -0.06046 |  0.0001273 |
| oheencoded_Entire_home/apt | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Staten_Island   | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Brooklyn        | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Shared_room     | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Manhattan       | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Bronx           | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| hotel                      | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Private_room    | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Queens          | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Hotel_room      | dummy      | 0.2279 | 0.1778 | 0.003448 | -0.1879  |  0         |
| oheencoded_Shared_room     | sgd-linear | 0.2385 | 0.1624 | 0.07272  | -0.06069 | -0.0001616 |
| oheencoded_Private_room    | sgd-linear | 0.2386 | 0.1624 | 0.07513  | -0.06091 | -0.0003761 |
| oheencoded_Entire_home/apt | sgd-linear | 0.2386 | 0.1624 | 0.07591  | -0.05972 | -0.0005586 |
| hotel                      | sgd-linear | 0.2386 | 0.1626 | 0.07211  | -0.06219 | -0.0007907 |
| oheencoded_Staten_Island   | sgd-linear | 0.2388 | 0.1626 | 0.07249  | -0.06349 | -0.0008987 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
