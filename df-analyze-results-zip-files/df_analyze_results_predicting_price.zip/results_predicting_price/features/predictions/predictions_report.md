# Continuous predictions

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| room                       | sgd-linear | 0.1771 | 0.4082 | 0.08698 | -0.008432 |  0.01812   |
| longitude                  | sgd-linear | 0.1827 | 0.4114 | 0.09794 | -0.01829  |  0.01229   |
| private                    | sgd-linear | 0.1838 | 0.4126 | 0.09556 | -0.02677  |  0.004051  |
| minimum_nights             | sgd-linear | 0.1841 | 0.4161 | 0.0934  | -0.04288  |  0.002509  |
| availability_365           | sgd-linear | 0.1846 | 0.4159 | 0.09511 | -0.04223  |  0.001648  |
| neighbourhood_labelencoded | sgd-linear | 0.1844 | 0.4162 | 0.09503 | -0.04244  |  0.001299  |
| in                         | sgd-linear | 0.1847 | 0.4163 | 0.09442 | -0.04452  |  0.0005163 |
| cozy                       | sgd-linear | 0.1847 | 0.4163 | 0.09497 | -0.04391  |  0.000202  |
| latitude                   | sgd-linear | 0.1848 | 0.4162 | 0.09531 | -0.04368  |  0.0001812 |
| latitude                   | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| in                         | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| availability_365           | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| number_of_reviews          | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| minimum_nights             | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| longitude                  | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| neighbourhood_labelencoded | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| luxury                     | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| luxury                     | sgd-linear | 0.1848 | 0.4166 | 0.09512 | -0.04536  |  0         |
| cozy                       | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| city                       | sgd-linear | 0.1848 | 0.4163 | 0.09511 | -0.04451  |  0         |
| city                       | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| floor                      | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| room                       | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| private                    | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272  |  0         |
| floor                      | sgd-linear | 0.1848 | 0.4163 | 0.09487 | -0.04374  | -4.441e-17 |
| number_of_reviews          | sgd-linear | 0.1848 | 0.4162 | 0.09553 | -0.0434   | -2.066e-05 |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |    mdae |       r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|---------:|-----------:|
| oheencoded_Entire_home/apt | sgd-linear | 0.1592 | 0.4034 | 0.06458 |  0.03021 |  0.06289   |
| oheencoded_Private_room    | sgd-linear | 0.1606 | 0.4043 | 0.06547 |  0.02597 |  0.05864   |
| oheencoded_Manhattan       | sgd-linear | 0.1792 | 0.4108 | 0.08997 | -0.01936 |  0.02244   |
| oheencoded_Queens          | sgd-linear | 0.1824 | 0.4136 | 0.09269 | -0.03134 |  0.01041   |
| oheencoded_Brooklyn        | sgd-linear | 0.184  | 0.4156 | 0.09491 | -0.04111 |  0.003035  |
| oheencoded_Bronx           | sgd-linear | 0.1847 | 0.4161 | 0.09575 | -0.04318 |  0.000502  |
| oheencoded_Shared_room     | sgd-linear | 0.1847 | 0.4159 | 0.0962  | -0.04235 |  0.0002417 |
| hotel                      | sgd-linear | 0.1847 | 0.4167 | 0.09441 | -0.04612 |  0.0001823 |
| oheencoded_Staten_Island   | sgd-linear | 0.1847 | 0.4162 | 0.09565 | -0.04272 |  0.000119  |
| oheencoded_Entire_home/apt | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| hotel                      | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Hotel_room      | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Brooklyn        | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Staten_Island   | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Queens          | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Shared_room     | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Private_room    | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Bronx           | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Manhattan       | dummy      | 0.1848 | 0.4179 | 0.09317 | -0.05272 |  0         |
| oheencoded_Hotel_room      | sgd-linear | 0.1848 | 0.4163 | 0.0953  | -0.04375 | -4.441e-17 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
