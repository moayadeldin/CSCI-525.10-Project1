# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |      F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|-------:|---------:|
| neighbourhood_labelencoded |    0.201   |     0.0404  |    4.68e-09 |       0.128  |     0        |  34.3  | 4.68e-09 |
| longitude                  |    0.155   |    -0.0824  |    0        |      -0.382  |     0        | 144    | 0        |
| latitude                   |    0.125   |     0.00899 |    0.193    |       0.0747 |     0        |   1.69 | 0.193    |
| room                       |    0.106   |    -0.0628  |    0        |      -0.41   |     0        |  83.1  | 0        |
| availability_365           |    0.1     |     0.0261  |    0.000153 |       0.114  |     0        |  14.3  | 0.000153 |
| minimum_nights             |    0.0777  |    -0.0371  |    7.71e-08 |      -0.172  |     0        |  28.9  | 7.71e-08 |
| number_of_reviews          |    0.0325  |    -0.0102  |    0.141    |       0.0385 |     2.45e-08 |   2.17 | 0.141    |
| private                    |    0.0153  |    -0.0268  |    0.000102 |      -0.204  |     0        |  15.1  | 0.000102 |
| cozy                       |    0.0111  |    -0.0372  |    7.14e-08 |      -0.113  |     0        |  29    | 7.14e-08 |
| in                         |    0.00663 |    -0.0321  |    3.28e-06 |      -0.0799 |     0        |  21.7  | 3.28e-06 |
| floor                      |    0.00553 |     0       |    0        |       0      |     0        |   0    | 1        |
| city                       |    0       |     0       |    0        |       0      |     0        |   0    | 1        |
| luxury                     |    0       |     0       |    0        |       0      |     0        |   0    | 1        |

# Categorical associations

|                            |   mut_info |          H |      H_p |
|:---------------------------|-----------:|-----------:|---------:|
| oheencoded_Entire_home/apt |    0.292   |   1.1e+04  | 0        |
| oheencoded_Private_room    |    0.267   |   4.61e+03 | 0        |
| oheencoded_Manhattan       |    0.0514  |   5.35e+03 | 0        |
| oheencoded_Queens          |    0.02    | 708        | 0        |
| oheencoded_Brooklyn        |    0.00971 |   4.92e+03 | 0        |
| oheencoded_Shared_room     |    0.00957 |  14.1      | 0.000169 |
| hotel                      |    0.0065  |   5.5      | 0.0191   |
| oheencoded_Bronx           |    0.00517 |  55.3      | 0        |
| oheencoded_Hotel_room      |    0.00156 |   3.13     | 0.0771   |
| oheencoded_Staten_Island   |    0       |  10.5      | 0.00117  |

**Note**: values less than 1e-10 are rounded to zero.
