# Filter-Based Feature Selection Summary


## Selected Features

['room', 'longitude', 'private', 'minimum_nights', 'neighbourhood_labelencoded', 'availability_365', 'in', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Manhattan', 'oheencoded_Queens', 'oheencoded_Brooklyn']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| room                       | -7.626e-03 |
| longitude                  | -2.014e-03 |
| private                    | -9.862e-04 |
| minimum_nights             | -6.576e-04 |
| neighbourhood_labelencoded | -3.369e-04 |
| availability_365           | -1.667e-04 |
| in                         | -6.827e-05 |
| cozy                       | -9.146e-06 |
| floor                      |  2.390e-05 |
| latitude                   |  2.645e-05 |
| luxury                     |  4.450e-05 |
| number_of_reviews          |  5.417e-05 |
| city                       |  7.308e-05 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| oheencoded_Entire_home/apt | -2.552e-02 |
| oheencoded_Private_room    | -2.417e-02 |
| oheencoded_Manhattan       | -5.595e-03 |
| oheencoded_Queens          | -2.348e-03 |
| oheencoded_Brooklyn        | -7.914e-04 |
| oheencoded_Bronx           | -2.753e-05 |
| oheencoded_Staten_Island   | -2.161e-05 |
| oheencoded_Shared_room     | -1.115e-05 |
| hotel                      | -9.082e-06 |
| oheencoded_Hotel_room      |  6.802e-05 |