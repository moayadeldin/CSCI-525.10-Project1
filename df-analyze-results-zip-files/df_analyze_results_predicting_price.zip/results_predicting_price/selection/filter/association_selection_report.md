# Filter-Based Feature Selection Summary


## Selected Features

['neighbourhood_labelencoded', 'longitude', 'latitude', 'room', 'availability_365', 'minimum_nights', 'number_of_reviews', 'private', 'cozy', 'in', 'floor', 'city', 'luxury', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Manhattan', 'oheencoded_Queens', 'oheencoded_Brooklyn', 'oheencoded_Shared_room', 'hotel', 'oheencoded_Bronx', 'oheencoded_Hotel_room', 'oheencoded_Staten_Island']

## Selection Association Scores 

### Continuous Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| neighbourhood_labelencoded |  2.009e-01 |
| longitude                  |  1.551e-01 |
| latitude                   |  1.245e-01 |
| room                       |  1.056e-01 |
| availability_365           |  1.001e-01 |
| minimum_nights             |  7.766e-02 |
| number_of_reviews          |  3.248e-02 |
| private                    |  1.534e-02 |
| cozy                       |  1.109e-02 |
| in                         |  6.627e-03 |
| floor                      |  5.534e-03 |
| city                       |  0.000e+00 |
| luxury                     |  0.000e+00 |

### Categorical Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| oheencoded_Entire_home/apt |  2.924e-01 |
| oheencoded_Private_room    |  2.668e-01 |
| oheencoded_Manhattan       |  5.136e-02 |
| oheencoded_Queens          |  2.003e-02 |
| oheencoded_Brooklyn        |  9.712e-03 |
| oheencoded_Shared_room     |  9.566e-03 |
| hotel                      |  6.499e-03 |
| oheencoded_Bronx           |  5.166e-03 |
| oheencoded_Hotel_room      |  1.564e-03 |
| oheencoded_Staten_Island   |  0.000e+00 |