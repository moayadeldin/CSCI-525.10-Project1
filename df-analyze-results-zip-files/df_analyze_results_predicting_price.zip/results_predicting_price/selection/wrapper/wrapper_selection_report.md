# Wrapper-Based Feature Selection Summary

Wrapper method:    StepUp
Wrapper model:     Linear
Redundancy-aware:  True

## Selected Features

['neighbourhood_labelencoded']

## Selection Scores (Mean Absolute Error: Lower = More important)

| feature                    |      score |
|:---------------------------|-----------:|
| neighbourhood_labelencoded | -2.037e-01 |

# Redundant Stepwise Selection Results

Metric: MAE

* neighbourhood_labelencoded (MAE=-0.20374) - [Iteration   0]

redundants                        score
------------------------------  -------
number_of_reviews               -0.2047
oheencoded_Manhattan_1.0        -0.2046
latitude                        -0.2046
longitude                       -0.2046
oheencoded_Hotel_room_1.0       -0.2046
oheencoded_Bronx_1.0            -0.2046
oheencoded_Staten_Island_1.0    -0.2046
oheencoded_Private_room_nan     -0.2046
oheencoded_Private_room_1.0     -0.2046
hotel_1.0                       -0.2046
oheencoded_Brooklyn_nan         -0.2046
oheencoded_Manhattan_nan        -0.2046
oheencoded_Entire_home/apt_1.0  -0.2046
oheencoded_Shared_room_nan      -0.2046
oheencoded_Staten_Island_nan    -0.2046
hotel_nan                       -0.2046
oheencoded_Queens_1.0           -0.2046
oheencoded_Brooklyn_1.0         -0.2046
oheencoded_Hotel_room_nan       -0.2046
oheencoded_Entire_home/apt_nan  -0.2046
cozy                            -0.2046
private                         -0.2046
oheencoded_Shared_room_1.0      -0.2046
room                            -0.2046
floor                           -0.2046
oheencoded_Queens_nan           -0.2046
city                            -0.2046
luxury                          -0.2046
in                              -0.2046
oheencoded_Bronx_nan            -0.2046
minimum_nights                  -0.2045
availability_365                -0.2040
neighbourhood_labelencoded      -0.2037

