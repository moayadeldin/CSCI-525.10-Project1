# Wrapper-Based Feature Selection Summary

Wrapper model:  Linear

## Selected Features

['latitude', 'longitude', 'minimum_nights', 'number_of_reviews', 'availability_365', 'neighbourhood_labelencoded', 'luxury', 'floor', 'city', 'private', 'in', 'cozy', 'room', 'hotel_1.0', 'oheencoded_Bronx_1.0', 'oheencoded_Brooklyn_1.0', 'oheencoded_Entire_home/apt_1.0', 'oheencoded_Hotel_room_1.0', 'oheencoded_Manhattan_1.0', 'oheencoded_Private_room_1.0', 'oheencoded_Queens_1.0', 'oheencoded_Shared_room_1.0', 'oheencoded_Staten_Island_1.0']

## Selection scores (Coefficients: Larger magnitude = More important)

| feature                        |      score |
|:-------------------------------|-----------:|
| latitude                       | -3.540e-03 |
| longitude                      | -2.206e-03 |
| minimum_nights                 | -9.184e-04 |
| number_of_reviews              | -1.527e-04 |
| availability_365               |  1.416e-04 |
| neighbourhood_labelencoded     |  1.723e-04 |
| luxury                         |  1.541e-02 |
| floor                          |  9.118e-04 |
| city                           |  1.385e-03 |
| private                        | -9.869e-03 |
| in                             | -1.083e-02 |
| cozy                           | -1.646e-02 |
| room                           | -2.343e-02 |
| hotel_1.0                      |  3.242e-03 |
| hotel_nan                      |  0.000e+00 |
| oheencoded_Bronx_1.0           | -9.409e-03 |
| oheencoded_Bronx_nan           |  0.000e+00 |
| oheencoded_Brooklyn_1.0        | -8.216e-03 |
| oheencoded_Brooklyn_nan        |  0.000e+00 |
| oheencoded_Entire_home/apt_1.0 |  6.678e-02 |
| oheencoded_Entire_home/apt_nan |  0.000e+00 |
| oheencoded_Hotel_room_1.0      |  9.302e-04 |
| oheencoded_Hotel_room_nan      |  0.000e+00 |
| oheencoded_Manhattan_1.0       |  4.178e-02 |
| oheencoded_Manhattan_nan       |  0.000e+00 |
| oheencoded_Private_room_1.0    | -6.216e-02 |
| oheencoded_Private_room_nan    |  0.000e+00 |
| oheencoded_Queens_1.0          | -2.218e-02 |
| oheencoded_Queens_nan          |  0.000e+00 |
| oheencoded_Shared_room_1.0     | -5.608e-03 |
| oheencoded_Shared_room_nan     |  0.000e+00 |
| oheencoded_Staten_Island_1.0   | -2.012e-03 |
| oheencoded_Staten_Island_nan   |  0.000e+00 |