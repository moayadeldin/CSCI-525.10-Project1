# Wrapper-Based Feature Selection Summary

Wrapper model:  LGBM

## Selected Features

['latitude', 'longitude', 'minimum_nights', 'number_of_reviews', 'availability_365', 'neighbourhood_labelencoded']

## Selection scores (Importances: Larger magnitude = More important)

| feature                        |     score |
|:-------------------------------|----------:|
| latitude                       | 8.810e+02 |
| longitude                      | 9.200e+02 |
| minimum_nights                 | 2.090e+02 |
| number_of_reviews              | 5.600e+02 |
| availability_365               | 3.290e+02 |
| neighbourhood_labelencoded     | 5.420e+02 |
| luxury                         | 1.500e+01 |
| floor                          | 0.000e+00 |
| city                           | 0.000e+00 |
| private                        | 2.600e+01 |
| in                             | 9.300e+01 |
| cozy                           | 1.700e+01 |
| room                           | 3.500e+01 |
| hotel_1.0                      | 0.000e+00 |
| hotel_nan                      | 0.000e+00 |
| oheencoded_Bronx_1.0           | 5.000e+00 |
| oheencoded_Bronx_nan           | 0.000e+00 |
| oheencoded_Brooklyn_1.0        | 6.800e+01 |
| oheencoded_Brooklyn_nan        | 0.000e+00 |
| oheencoded_Entire_home/apt_1.0 | 5.500e+01 |
| oheencoded_Entire_home/apt_nan | 0.000e+00 |
| oheencoded_Hotel_room_1.0      | 0.000e+00 |
| oheencoded_Hotel_room_nan      | 0.000e+00 |
| oheencoded_Manhattan_1.0       | 6.200e+01 |
| oheencoded_Manhattan_nan       | 0.000e+00 |
| oheencoded_Private_room_1.0    | 3.300e+01 |
| oheencoded_Private_room_nan    | 0.000e+00 |
| oheencoded_Queens_1.0          | 1.800e+01 |
| oheencoded_Queens_nan          | 0.000e+00 |
| oheencoded_Shared_room_1.0     | 4.000e+00 |
| oheencoded_Shared_room_nan     | 0.000e+00 |
| oheencoded_Staten_Island_1.0   | 1.200e+01 |
| oheencoded_Staten_Island_nan   | 0.000e+00 |