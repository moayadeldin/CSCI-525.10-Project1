# Continuous predictions

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| room                       | sgd-linear | 0.1725 | 0.2892 | 0.08834 |  0.002431 |  0.02478   |
| longitude                  | sgd-linear | 0.1774 | 0.2911 | 0.09969 | -0.01607  |  0.01301   |
| minimum_nights             | sgd-linear | 0.1784 | 0.2928 | 0.1018  | -0.01965  |  0.007266  |
| private                    | sgd-linear | 0.1794 | 0.293  | 0.09898 | -0.02229  |  0.003847  |
| availability_365           | sgd-linear | 0.18   | 0.2951 | 0.09927 | -0.03613  |  0.002912  |
| neighbourhood_labelencoded | sgd-linear | 0.1798 | 0.2948 | 0.1002  | -0.03433  |  0.002116  |
| cozy                       | sgd-linear | 0.1801 | 0.2953 | 0.1003  | -0.03743  |  0.0003965 |
| latitude                   | sgd-linear | 0.1802 | 0.2953 | 0.09977 | -0.03653  |  0.0003554 |
| in                         | sgd-linear | 0.1802 | 0.2956 | 0.09937 | -0.03753  |  0.0003546 |
| luxury                     | sgd-linear | 0.1802 | 0.2956 | 0.09952 | -0.03835  |  6.661e-17 |
| latitude                   | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| longitude                  | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| availability_365           | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| minimum_nights             | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| neighbourhood_labelencoded | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| luxury                     | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| in                         | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| private                    | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| city                       | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| floor                      | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| cozy                       | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| room                       | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| city                       | sgd-linear | 0.1802 | 0.2955 | 0.09989 | -0.03776  | -2.22e-17  |
| floor                      | sgd-linear | 0.1801 | 0.2955 | 0.1     | -0.03817  | -2.22e-17  |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| oheencoded_Entire_home/apt | sgd-linear | 0.1543 | 0.2817 | 0.06624 |  0.04606  |  0.07554   |
| oheencoded_Private_room    | sgd-linear | 0.1563 | 0.2828 | 0.06754 |  0.04127  |  0.06961   |
| oheencoded_Manhattan       | sgd-linear | 0.1747 | 0.2904 | 0.09214 | -0.009045 |  0.02838   |
| oheencoded_Brooklyn        | sgd-linear | 0.1788 | 0.2933 | 0.09391 | -0.02837  |  0.009211  |
| oheencoded_Queens          | sgd-linear | 0.1785 | 0.2941 | 0.09753 | -0.03076  |  0.007084  |
| oheencoded_Shared_room     | sgd-linear | 0.1795 | 0.2944 | 0.09901 | -0.03212  |  0.00205   |
| oheencoded_Bronx           | sgd-linear | 0.1801 | 0.2954 | 0.09995 | -0.03751  |  0.0002952 |
| hotel                      | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Private_room    | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Bronx           | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Queens          | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Staten_Island   | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Shared_room     | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Manhattan       | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Brooklyn        | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Entire_home/apt | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Hotel_room      | dummy      | 0.18   | 0.2967 | 0.09837 | -0.04359  |  0         |
| oheencoded_Hotel_room      | sgd-linear | 0.18   | 0.2954 | 0.1003  | -0.03793  | -3.842e-06 |
| hotel                      | sgd-linear | 0.1801 | 0.2957 | 0.09991 | -0.03832  | -2.376e-05 |
| oheencoded_Staten_Island   | sgd-linear | 0.1801 | 0.2958 | 0.09921 | -0.03902  | -0.0001511 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
