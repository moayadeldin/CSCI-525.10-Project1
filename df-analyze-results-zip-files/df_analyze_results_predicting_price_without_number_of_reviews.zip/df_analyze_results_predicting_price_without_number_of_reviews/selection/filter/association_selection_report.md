# Filter-Based Feature Selection Summary


## Selected Features

['neighbourhood_labelencoded', 'longitude', 'latitude', 'room', 'availability_365', 'minimum_nights', 'private', 'cozy', 'in', 'floor', 'luxury', 'city', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Manhattan', 'oheencoded_Queens', 'oheencoded_Brooklyn', 'oheencoded_Shared_room', 'oheencoded_Bronx', 'hotel', 'oheencoded_Hotel_room', 'oheencoded_Staten_Island']

## Selection Association Scores 

### Continuous Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| neighbourhood_labelencoded |  2.072e-01 |
| longitude                  |  1.552e-01 |
| latitude                   |  1.245e-01 |
| room                       |  1.032e-01 |
| availability_365           |  9.272e-02 |
| minimum_nights             |  7.692e-02 |
| private                    |  1.893e-02 |
| cozy                       |  1.078e-02 |
| in                         |  8.909e-03 |
| floor                      |  7.810e-03 |
| luxury                     |  5.894e-03 |
| city                       |  2.130e-03 |

### Categorical Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| oheencoded_Entire_home/apt |  2.868e-01 |
| oheencoded_Private_room    |  2.661e-01 |
| oheencoded_Manhattan       |  5.452e-02 |
| oheencoded_Queens          |  1.975e-02 |
| oheencoded_Brooklyn        |  1.628e-02 |
| oheencoded_Shared_room     |  1.005e-02 |
| oheencoded_Bronx           |  6.380e-03 |
| hotel                      |  6.351e-03 |
| oheencoded_Hotel_room      |  1.452e-03 |
| oheencoded_Staten_Island   |  6.336e-05 |