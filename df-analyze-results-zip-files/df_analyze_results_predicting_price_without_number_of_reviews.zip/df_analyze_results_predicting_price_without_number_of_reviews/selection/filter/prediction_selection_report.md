# Filter-Based Feature Selection Summary


## Selected Features

['room', 'longitude', 'minimum_nights', 'private', 'neighbourhood_labelencoded', 'availability_365', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Manhattan', 'oheencoded_Queens', 'oheencoded_Brooklyn']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| room                       | -7.455e-03 |
| longitude                  | -2.525e-03 |
| minimum_nights             | -1.581e-03 |
| private                    | -5.521e-04 |
| neighbourhood_labelencoded | -1.734e-04 |
| availability_365           |  4.071e-05 |
| cozy                       |  1.045e-04 |
| floor                      |  1.316e-04 |
| luxury                     |  1.902e-04 |
| in                         |  2.130e-04 |
| city                       |  2.196e-04 |
| latitude                   |  2.202e-04 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| oheencoded_Entire_home/apt | -2.566e-02 |
| oheencoded_Private_room    | -2.366e-02 |
| oheencoded_Manhattan       | -5.237e-03 |
| oheencoded_Queens          | -1.473e-03 |
| oheencoded_Brooklyn        | -1.215e-03 |
| oheencoded_Shared_room     | -5.082e-04 |
| oheencoded_Hotel_room      |  7.270e-05 |
| oheencoded_Bronx           |  1.115e-04 |
| oheencoded_Staten_Island   |  1.426e-04 |
| hotel                      |  1.592e-04 |