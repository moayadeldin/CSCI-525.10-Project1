# Wrapper-Based Feature Selection Summary

Wrapper model:  LGBM

## Selected Features

['latitude', 'longitude', 'minimum_nights', 'availability_365', 'neighbourhood_labelencoded', 'oheencoded_Manhattan_1.0']

## Selection scores (Importances: Larger magnitude = More important)

| feature                        |     score |
|:-------------------------------|----------:|
| latitude                       | 1.130e+02 |
| longitude                      | 1.640e+02 |
| minimum_nights                 | 7.100e+01 |
| availability_365               | 7.800e+01 |
| neighbourhood_labelencoded     | 5.300e+01 |
| luxury                         | 1.300e+01 |
| floor                          | 0.000e+00 |
| city                           | 0.000e+00 |
| private                        | 3.000e+00 |
| in                             | 1.600e+01 |
| cozy                           | 1.600e+01 |
| room                           | 8.000e+00 |
| hotel_1.0                      | 0.000e+00 |
| hotel_nan                      | 0.000e+00 |
| oheencoded_Bronx_1.0           | 0.000e+00 |
| oheencoded_Bronx_nan           | 0.000e+00 |
| oheencoded_Brooklyn_1.0        | 2.000e+00 |
| oheencoded_Brooklyn_nan        | 0.000e+00 |
| oheencoded_Entire_home/apt_1.0 | 1.200e+01 |
| oheencoded_Entire_home/apt_nan | 0.000e+00 |
| oheencoded_Hotel_room_1.0      | 0.000e+00 |
| oheencoded_Hotel_room_nan      | 0.000e+00 |
| oheencoded_Manhattan_1.0       | 2.300e+01 |
| oheencoded_Manhattan_nan       | 0.000e+00 |
| oheencoded_Private_room_1.0    | 1.700e+01 |
| oheencoded_Private_room_nan    | 0.000e+00 |
| oheencoded_Queens_1.0          | 1.000e+00 |
| oheencoded_Queens_nan          | 0.000e+00 |
| oheencoded_Shared_room_1.0     | 5.000e+00 |
| oheencoded_Shared_room_nan     | 0.000e+00 |
| oheencoded_Staten_Island_1.0   | 5.000e+00 |
| oheencoded_Staten_Island_nan   | 0.000e+00 |