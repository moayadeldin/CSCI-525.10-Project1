# Data Preparation Summary

Task:                   Regression
Data original shape:    34977 samples × 26 features
Data final shape:       34977 samples × 32 features
Target feature:         price

Samples dropped due to NaN target: 0
Indicator variables added for continuous NaNs: 0

# Processing Times

| computation             |   runtime (ms) |
|:------------------------|---------------:|
| unify_nans              |           1208 |
| convert_categoricals    |              6 |
| inspect_target          |             47 |
| drop_target_nans        |             61 |
| clean_regression_target |             24 |
| drop_unusable           |              2 |
| deflate_categoricals    |              4 |
| encode_categoricals     |            985 |