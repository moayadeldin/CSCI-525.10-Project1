# Filter-Based Feature Selection Summary


## Selected Features

['availability_365', 'price', 'neighbourhood_labelencoded', 'longitude', 'cozy', 'latitude', 'oheencoded_Manhattan', 'oheencoded_Brooklyn', 'oheencoded_Bronx', 'oheencoded_Queens', 'hotel']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| availability_365           | 8.570e-03 |
| price                      | 1.040e-02 |
| neighbourhood_labelencoded | 1.053e-02 |
| longitude                  | 1.055e-02 |
| cozy                       | 1.065e-02 |
| latitude                   | 1.070e-02 |
| floor                      | 1.070e-02 |
| luxury                     | 1.073e-02 |
| city                       | 1.073e-02 |
| private                    | 1.078e-02 |
| room                       | 1.080e-02 |
| in                         | 1.085e-02 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| oheencoded_Manhattan       | 8.342e-03 |
| oheencoded_Brooklyn        | 1.035e-02 |
| oheencoded_Bronx           | 1.048e-02 |
| oheencoded_Queens          | 1.058e-02 |
| hotel                      | 1.059e-02 |
| oheencoded_Shared_room     | 1.065e-02 |
| oheencoded_Entire_home/apt | 1.067e-02 |
| oheencoded_Hotel_room      | 1.074e-02 |
| oheencoded_Staten_Island   | 1.075e-02 |
| oheencoded_Private_room    | 1.085e-02 |