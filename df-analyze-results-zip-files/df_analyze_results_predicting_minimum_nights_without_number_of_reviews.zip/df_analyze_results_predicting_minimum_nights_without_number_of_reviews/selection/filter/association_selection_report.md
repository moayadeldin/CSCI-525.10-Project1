# Filter-Based Feature Selection Summary


## Selected Features

['availability_365', 'longitude', 'price', 'latitude', 'neighbourhood_labelencoded', 'cozy', 'luxury', 'in', 'city', 'floor', 'private', 'room', 'oheencoded_Private_room', 'oheencoded_Brooklyn', 'oheencoded_Manhattan', 'oheencoded_Entire_home/apt', 'oheencoded_Bronx', 'hotel', 'oheencoded_Staten_Island', 'oheencoded_Queens', 'oheencoded_Shared_room', 'oheencoded_Hotel_room']

## Selection Association Scores 

### Continuous Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| availability_365           |  1.205e-01 |
| longitude                  |  8.886e-02 |
| price                      |  8.455e-02 |
| latitude                   |  8.223e-02 |
| neighbourhood_labelencoded |  7.510e-02 |
| cozy                       |  1.704e-03 |
| luxury                     |  1.597e-03 |
| in                         |  1.317e-03 |
| city                       |  0.000e+00 |
| floor                      |  0.000e+00 |
| private                    |  0.000e+00 |
| room                       |  0.000e+00 |

### Categorical Features (Mutual Information: Higher = More important)

|                            |   mut_info |
|:---------------------------|-----------:|
| oheencoded_Private_room    |  1.450e-02 |
| oheencoded_Brooklyn        |  1.283e-02 |
| oheencoded_Manhattan       |  1.235e-02 |
| oheencoded_Entire_home/apt |  8.523e-03 |
| oheencoded_Bronx           |  4.500e-03 |
| hotel                      |  2.165e-03 |
| oheencoded_Staten_Island   |  1.472e-03 |
| oheencoded_Queens          |  9.280e-04 |
| oheencoded_Shared_room     |  8.743e-04 |
| oheencoded_Hotel_room      |  4.169e-04 |