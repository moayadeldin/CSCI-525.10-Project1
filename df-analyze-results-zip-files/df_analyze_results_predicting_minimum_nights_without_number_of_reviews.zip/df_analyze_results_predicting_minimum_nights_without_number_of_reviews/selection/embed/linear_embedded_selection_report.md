# Wrapper-Based Feature Selection Summary

Wrapper model:  Linear

## Selected Features

['latitude', 'longitude', 'price', 'availability_365', 'neighbourhood_labelencoded', 'luxury', 'floor', 'city', 'private', 'in', 'cozy', 'room', 'hotel_1.0', 'oheencoded_Bronx_1.0', 'oheencoded_Brooklyn_1.0', 'oheencoded_Entire_home/apt_1.0', 'oheencoded_Hotel_room_1.0', 'oheencoded_Manhattan_1.0', 'oheencoded_Private_room_1.0', 'oheencoded_Queens_1.0', 'oheencoded_Shared_room_1.0', 'oheencoded_Staten_Island_1.0']

## Selection scores (Coefficients: Larger magnitude = More important)

| feature                        |      score |
|:-------------------------------|-----------:|
| latitude                       | -4.592e-03 |
| longitude                      | -1.514e-03 |
| price                          | -1.143e-04 |
| availability_365               | -5.620e-04 |
| neighbourhood_labelencoded     |  1.247e-04 |
| luxury                         |  4.035e-03 |
| floor                          | -2.381e-03 |
| city                           | -5.467e-03 |
| private                        | -1.793e-02 |
| in                             | -1.282e-02 |
| cozy                           | -1.983e-02 |
| room                           |  1.974e-02 |
| hotel_1.0                      | -5.731e-03 |
| hotel_nan                      |  0.000e+00 |
| oheencoded_Bronx_1.0           | -2.857e-02 |
| oheencoded_Bronx_nan           |  0.000e+00 |
| oheencoded_Brooklyn_1.0        | -5.195e-03 |
| oheencoded_Brooklyn_nan        |  0.000e+00 |
| oheencoded_Entire_home/apt_1.0 | -1.142e-02 |
| oheencoded_Entire_home/apt_nan |  0.000e+00 |
| oheencoded_Hotel_room_1.0      |  8.173e-04 |
| oheencoded_Hotel_room_nan      |  0.000e+00 |
| oheencoded_Manhattan_1.0       |  6.352e-02 |
| oheencoded_Manhattan_nan       |  0.000e+00 |
| oheencoded_Private_room_1.0    |  9.216e-03 |
| oheencoded_Private_room_nan    |  0.000e+00 |
| oheencoded_Queens_1.0          | -2.221e-02 |
| oheencoded_Queens_nan          |  0.000e+00 |
| oheencoded_Shared_room_1.0     |  2.454e-04 |
| oheencoded_Shared_room_nan     |  0.000e+00 |
| oheencoded_Staten_Island_1.0   | -6.156e-03 |
| oheencoded_Staten_Island_nan   |  0.000e+00 |