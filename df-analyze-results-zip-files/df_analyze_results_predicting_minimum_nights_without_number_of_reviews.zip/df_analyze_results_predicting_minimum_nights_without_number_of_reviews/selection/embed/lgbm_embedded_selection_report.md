# Wrapper-Based Feature Selection Summary

Wrapper model:  LGBM

## Selected Features

['latitude', 'longitude', 'price', 'availability_365', 'neighbourhood_labelencoded']

## Selection scores (Importances: Larger magnitude = More important)

| feature                        |     score |
|:-------------------------------|----------:|
| latitude                       | 2.001e+03 |
| longitude                      | 2.108e+03 |
| price                          | 1.768e+03 |
| availability_365               | 1.093e+03 |
| neighbourhood_labelencoded     | 9.310e+02 |
| luxury                         | 2.300e+01 |
| floor                          | 8.000e+00 |
| city                           | 1.000e+01 |
| private                        | 6.200e+01 |
| in                             | 1.790e+02 |
| cozy                           | 3.900e+01 |
| room                           | 1.030e+02 |
| hotel_1.0                      | 0.000e+00 |
| hotel_nan                      | 0.000e+00 |
| oheencoded_Bronx_1.0           | 1.100e+01 |
| oheencoded_Bronx_nan           | 0.000e+00 |
| oheencoded_Brooklyn_1.0        | 9.900e+01 |
| oheencoded_Brooklyn_nan        | 0.000e+00 |
| oheencoded_Entire_home/apt_1.0 | 1.590e+02 |
| oheencoded_Entire_home/apt_nan | 0.000e+00 |
| oheencoded_Hotel_room_1.0      | 0.000e+00 |
| oheencoded_Hotel_room_nan      | 0.000e+00 |
| oheencoded_Manhattan_1.0       | 6.900e+01 |
| oheencoded_Manhattan_nan       | 0.000e+00 |
| oheencoded_Private_room_1.0    | 1.210e+02 |
| oheencoded_Private_room_nan    | 0.000e+00 |
| oheencoded_Queens_1.0          | 2.500e+01 |
| oheencoded_Queens_nan          | 0.000e+00 |
| oheencoded_Shared_room_1.0     | 2.600e+01 |
| oheencoded_Shared_room_nan     | 0.000e+00 |
| oheencoded_Staten_Island_1.0   | 1.000e+00 |
| oheencoded_Staten_Island_nan   | 0.000e+00 |