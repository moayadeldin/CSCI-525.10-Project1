# Wrapper-Based Feature Selection Summary

Wrapper method:    StepUp
Wrapper model:     Linear
Redundancy-aware:  True

## Selected Features

['availability_365']

## Selection Scores (Mean Absolute Error: Lower = More important)

| feature          |      score |
|:-----------------|-----------:|
| availability_365 | -2.557e-01 |

# Redundant Stepwise Selection Results

Metric: MAE

* availability_365 (MAE=-0.25566) - [Iteration   0]

redundants                        score
------------------------------  -------
oheencoded_Bronx_nan            -0.2578
cozy                            -0.2578
in                              -0.2578
oheencoded_Hotel_room_nan       -0.2578
oheencoded_Queens_1.0           -0.2578
oheencoded_Entire_home/apt_nan  -0.2578
oheencoded_Staten_Island_nan    -0.2578
oheencoded_Brooklyn_nan         -0.2578
city                            -0.2578
oheencoded_Queens_nan           -0.2578
floor                           -0.2578
hotel_nan                       -0.2578
luxury                          -0.2578
oheencoded_Shared_room_1.0      -0.2578
oheencoded_Private_room_1.0     -0.2578
oheencoded_Staten_Island_1.0    -0.2578
room                            -0.2578
latitude                        -0.2578
private                         -0.2578
oheencoded_Manhattan_nan        -0.2578
longitude                       -0.2578
oheencoded_Bronx_1.0            -0.2578
oheencoded_Entire_home/apt_1.0  -0.2578
oheencoded_Hotel_room_1.0       -0.2578
hotel_1.0                       -0.2578
oheencoded_Manhattan_1.0        -0.2578
oheencoded_Brooklyn_1.0         -0.2578
oheencoded_Private_room_nan     -0.2578
oheencoded_Shared_room_nan      -0.2578
price                           -0.2576
neighbourhood_labelencoded      -0.2574
availability_365                -0.2557

