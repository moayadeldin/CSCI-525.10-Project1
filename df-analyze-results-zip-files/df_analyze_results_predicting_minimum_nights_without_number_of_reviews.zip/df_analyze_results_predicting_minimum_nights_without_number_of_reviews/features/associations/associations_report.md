# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |      F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|-------:|---------:|
| availability_365           |    0.121   |     -0.0438 |    2.14e-10 |     -0.194   |     0        |  40.4  | 2.14e-10 |
| longitude                  |    0.0889  |     -0.0852 |    0        |     -0.157   |     0        | 154    | 0        |
| price                      |    0.0845  |     -0.0666 |    0        |     -0.172   |     0        |  93.6  | 0        |
| latitude                   |    0.0822  |      0.0414 |    2.03e-09 |      0.102   |     0        |  36    | 2.03e-09 |
| neighbourhood_labelencoded |    0.0751  |      0.0291 |    2.48e-05 |      0.0689  |     0        |  17.8  | 2.48e-05 |
| cozy                       |    0.0017  |     -0.0273 |    7.87e-05 |     -0.0378  |     4.18e-08 |  15.6  | 7.87e-05 |
| luxury                     |    0.0016  |      0      |    0        |      0       |     0        |   0    | 1        |
| in                         |    0.00132 |     -0.0177 |    0.0102   |     -0.00257 |     0.709    |   6.61 | 0.0102   |
| city                       |    0       |      0      |    0        |      0       |     0        |   0    | 1        |
| floor                      |    0       |      0      |    0        |      0       |     0        |   0    | 1        |
| private                    |    0       |     -0.0121 |    0.0789   |     -0.0188  |     0.00644  |   3.09 | 0.0789   |
| room                       |    0       |      0.0381 |    3.35e-08 |      0.0479  |     0        |  30.5  | 3.35e-08 |

# Categorical associations

|                            |   mut_info |        H |   H_p |
|:---------------------------|-----------:|---------:|------:|
| oheencoded_Private_room    |   0.0145   | 1.4e+04  |     0 |
| oheencoded_Brooklyn        |   0.0128   | 1.42e+04 |     0 |
| oheencoded_Manhattan       |   0.0123   | 1.46e+04 |     0 |
| oheencoded_Entire_home/apt |   0.00852  | 1.89e+04 |     0 |
| oheencoded_Bronx           |   0.0045   | 8.28e+03 |     0 |
| hotel                      |   0.00216  | 7.92e+03 |     0 |
| oheencoded_Staten_Island   |   0.00147  | 7.98e+03 |     0 |
| oheencoded_Queens          |   0.000928 | 9.79e+03 |     0 |
| oheencoded_Shared_room     |   0.000874 | 8.02e+03 |     0 |
| oheencoded_Hotel_room      |   0.000417 | 7.88e+03 |     0 |

**Note**: values less than 1e-10 are rounded to zero.
