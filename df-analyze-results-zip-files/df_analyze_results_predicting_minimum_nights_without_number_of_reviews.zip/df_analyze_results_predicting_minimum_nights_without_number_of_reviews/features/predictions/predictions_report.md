# Continuous predictions

| feature                    | model      |    mae |   msqe |     mdae |       r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|---------:|---------:|-----------:|
| availability_365           | sgd-linear | 0.2427 | 0.1953 | 0.12     | -0.05627 |  0.01045   |
| longitude                  | sgd-linear | 0.2446 | 0.1973 | 0.07891  | -0.06901 |  0.00205   |
| price                      | sgd-linear | 0.2445 | 0.1977 | 0.0798   | -0.07175 |  0.001519  |
| private                    | sgd-linear | 0.2449 | 0.1979 | 0.07431  | -0.07292 |  0.0001169 |
| cozy                       | sgd-linear | 0.2447 | 0.1979 | 0.07371  | -0.07284 |  6.805e-05 |
| room                       | sgd-linear | 0.2449 | 0.1979 | 0.07319  | -0.07284 |  7.271e-06 |
| luxury                     | sgd-linear | 0.2448 | 0.1978 | 0.07311  | -0.0713  |  4.441e-17 |
| floor                      | sgd-linear | 0.2448 | 0.1978 | 0.07303  | -0.07128 |  4.441e-17 |
| cozy                       | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| availability_365           | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| longitude                  | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| price                      | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| latitude                   | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| city                       | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| luxury                     | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| neighbourhood_labelencoded | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| room                       | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| city                       | sgd-linear | 0.2448 | 0.198  | 0.07265  | -0.07326 |  0         |
| floor                      | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| private                    | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| in                         | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| in                         | sgd-linear | 0.2449 | 0.1979 | 0.07356  | -0.0729  | -4.396e-05 |
| neighbourhood_labelencoded | sgd-linear | 0.2446 | 0.1982 | 0.07228  | -0.07536 | -0.0003487 |
| latitude                   | sgd-linear | 0.2448 | 0.1982 | 0.0747   | -0.0755  | -0.0007143 |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |     mdae |       r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|---------:|---------:|-----------:|
| oheencoded_Manhattan       | sgd-linear | 0.2424 | 0.1961 | 0.08938  | -0.06008 |  0.007647  |
| oheencoded_Brooklyn        | sgd-linear | 0.2444 | 0.1975 | 0.08218  | -0.07024 |  0.001442  |
| oheencoded_Queens          | sgd-linear | 0.2447 | 0.1979 | 0.07637  | -0.07392 |  0.0005952 |
| oheencoded_Shared_room     | sgd-linear | 0.2447 | 0.1979 | 0.07351  | -0.07355 |  0.0002024 |
| oheencoded_Hotel_room      | sgd-linear | 0.2448 | 0.1979 | 0.07286  | -0.07334 |  1.416e-05 |
| oheencoded_Manhattan       | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Hotel_room      | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Queens          | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Entire_home/apt | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Staten_Island   | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Bronx           | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| hotel                      | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Shared_room     | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Brooklyn        | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Private_room    | dummy      | 0.2341 | 0.2128 | 0.008621 | -0.1993  |  0         |
| oheencoded_Bronx           | sgd-linear | 0.2446 | 0.1981 | 0.07134  | -0.07472 | -3.233e-05 |
| hotel                      | sgd-linear | 0.2447 | 0.1982 | 0.07137  | -0.076   | -0.0003246 |
| oheencoded_Entire_home/apt | sgd-linear | 0.2448 | 0.198  | 0.07786  | -0.07279 | -0.0003524 |
| oheencoded_Staten_Island   | sgd-linear | 0.2448 | 0.1982 | 0.07233  | -0.07565 | -0.0004804 |
| oheencoded_Private_room    | sgd-linear | 0.2449 | 0.1981 | 0.07761  | -0.07348 | -0.0008833 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
