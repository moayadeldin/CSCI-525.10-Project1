# Data Preparation Summary

Task:                   Regression
Data original shape:    34977 samples × 26 features
Data final shape:       34977 samples × 32 features
Target feature:         minimum_nights

Samples dropped due to NaN target: 0
Indicator variables added for continuous NaNs: 0

# Processing Times

| computation             |   runtime (ms) |
|:------------------------|---------------:|
| unify_nans              |           1246 |
| convert_categoricals    |              7 |
| inspect_target          |             51 |
| drop_target_nans        |             67 |
| clean_regression_target |             26 |
| drop_unusable           |              3 |
| deflate_categoricals    |              6 |
| encode_categoricals     |            990 |