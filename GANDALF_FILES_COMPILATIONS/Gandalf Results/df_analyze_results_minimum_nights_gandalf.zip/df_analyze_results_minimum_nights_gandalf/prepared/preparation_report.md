# Data Preparation Summary

Task:                   Regression
Data original shape:    34977 samples × 27 features
Data final shape:       34977 samples × 23 features
Target feature:         minimum_nights

Samples dropped due to NaN target: 0
Indicator variables added for continuous NaNs: 0

# Processing Times

| computation             |   runtime (ms) |
|:------------------------|---------------:|
| unify_nans              |           2042 |
| convert_categoricals    |              8 |
| inspect_target          |             75 |
| drop_target_nans        |             99 |
| clean_regression_target |             32 |
| drop_unusable           |           2816 |
| deflate_categoricals    |              3 |
| encode_categoricals     |           9200 |