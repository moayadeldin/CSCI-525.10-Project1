# Continuous predictions

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| number_of_reviews          | sgd-linear | 0.1927 | 0.4497 | 0.04454 |  0.0375   |  0.03928   |
| availability_365           | sgd-linear | 0.2043 | 0.4601 | 0.03614 | -0.004753 |  0.00108   |
| longitude                  | sgd-linear | 0.2059 | 0.4598 | 0.03795 | -0.006488 |  0.0001874 |
| price                      | sgd-linear | 0.2056 | 0.4598 | 0.03696 | -0.0066   |  0.0001591 |
| private                    | sgd-linear | 0.2057 | 0.4598 | 0.03662 | -0.00673  |  6.074e-05 |
| room                       | sgd-linear | 0.2057 | 0.4598 | 0.03692 | -0.006854 |  9.653e-06 |
| cozy                       | sgd-linear | 0.2057 | 0.4598 | 0.03687 | -0.006587 |  1.343e-06 |
| floor                      | sgd-linear | 0.2058 | 0.4598 | 0.03718 | -0.00653  |  2.22e-17  |
| floor                      | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| room                       | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| cozy                       | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| in                         | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| private                    | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| city                       | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| latitude                   | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| luxury                     | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| neighbourhood_labelencoded | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| availability_365           | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| number_of_reviews          | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| price                      | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| longitude                  | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| luxury                     | sgd-linear | 0.2058 | 0.4598 | 0.03709 | -0.006846 |  0         |
| city                       | sgd-linear | 0.2058 | 0.4598 | 0.03719 | -0.006602 | -1.776e-16 |
| in                         | sgd-linear | 0.2059 | 0.4598 | 0.03729 | -0.00665  | -1.433e-06 |
| neighbourhood_labelencoded | sgd-linear | 0.2055 | 0.4599 | 0.03656 | -0.006949 | -4.589e-06 |
| latitude                   | sgd-linear | 0.2056 | 0.46   | 0.03712 | -0.007187 | -0.0001506 |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| oheencoded_Manhattan       | sgd-linear | 0.205  | 0.4593 | 0.047   | -0.0051   |  0.001749  |
| oheencoded_Brooklyn        | sgd-linear | 0.2057 | 0.4595 | 0.04714 | -0.005653 |  0.0008948 |
| hotel                      | sgd-linear | 0.2055 | 0.4598 | 0.03648 | -0.006745 |  1.846e-05 |
| oheencoded_Hotel_room      | sgd-linear | 0.2057 | 0.4599 | 0.03695 | -0.006953 |  5.523e-06 |
| hotel                      | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Staten_Island   | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Shared_room     | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Queens          | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Private_room    | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Manhattan       | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Hotel_room      | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Entire_home/apt | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Brooklyn        | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Bronx           | dummy      | 0.1902 | 0.4634 | 0       | -0.02286  |  0         |
| oheencoded_Shared_room     | sgd-linear | 0.2052 | 0.4599 | 0.036   | -0.00695  | -2.286e-05 |
| oheencoded_Queens          | sgd-linear | 0.2057 | 0.4598 | 0.03676 | -0.006786 | -5.159e-05 |
| oheencoded_Staten_Island   | sgd-linear | 0.2054 | 0.4599 | 0.03609 | -0.007103 | -0.0001859 |
| oheencoded_Bronx           | sgd-linear | 0.2052 | 0.46   | 0.03567 | -0.007363 | -0.000195  |
| oheencoded_Private_room    | sgd-linear | 0.2059 | 0.4598 | 0.03855 | -0.006821 | -0.0002162 |
| oheencoded_Entire_home/apt | sgd-linear | 0.2057 | 0.4598 | 0.03869 | -0.006796 | -0.0002335 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
