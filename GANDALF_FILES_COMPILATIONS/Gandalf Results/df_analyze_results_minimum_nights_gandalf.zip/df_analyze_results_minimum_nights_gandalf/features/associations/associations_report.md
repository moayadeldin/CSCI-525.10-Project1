# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |       F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|--------:|---------:|
| number_of_reviews          |   0.142    |    -0.196   |    0        |     -0.464   |      0       | 700     | 0        |
| availability_365           |   0.111    |    -0.038   |    5.15e-07 |     -0.278   |      0       |  25.2   | 5.15e-07 |
| longitude                  |   0.0503   |    -0.066   |    0        |     -0.132   |      0       |  76.4   | 0        |
| latitude                   |   0.0458   |     0.0439  |    6.14e-09 |      0.106   |      0       |  33.8   | 6.14e-09 |
| price                      |   0.0415   |    -0.00875 |    0.247    |     -0.0954  |      0       |   1.34  | 0.247    |
| neighbourhood_labelencoded |   0.036    |     0.0325  |    1.72e-05 |      0.0737  |      0       |  18.5   | 1.72e-05 |
| in                         |   0.0147   |    -0.0089  |    0.239    |      0.0235  |      0.00192 |   1.38  | 0.239    |
| floor                      |   0.00641  |     0       |    0        |      0       |      0       |   0     | 1        |
| cozy                       |   1.05e-05 |    -0.0123  |    0.105    |     -0.00871 |      0.25    |   2.64  | 0.105    |
| luxury                     |   0        |     0       |    0        |      0       |      0       |   0     | 1        |
| city                       |   0        |     0       |    0        |      0       |      0       |   0     | 1        |
| private                    |   0        |    -0.0347  |    4.33e-06 |     -0.0563  |      0       |  21.1   | 4.33e-06 |
| room                       |   0        |    -0.00513 |    0.497    |      0.0171  |      0.0238  |   0.461 | 0.497    |

# Categorical associations

|                            |   mut_info |        H |   H_p |
|:---------------------------|-----------:|---------:|------:|
| oheencoded_Manhattan       |   0.014    | 1.09e+04 |     0 |
| oheencoded_Brooklyn        |   0.00902  | 1.08e+04 |     0 |
| oheencoded_Queens          |   0.00334  | 5.45e+03 |     0 |
| oheencoded_Entire_home/apt |   0.00247  | 1.41e+04 |     0 |
| oheencoded_Staten_Island   |   0.00199  | 3.98e+03 |     0 |
| oheencoded_Shared_room     |   0.00149  | 4.05e+03 |     0 |
| oheencoded_Private_room    |   0.00129  | 1.06e+04 |     0 |
| oheencoded_Bronx           |   0.000768 | 4.2e+03  |     0 |
| hotel                      |   0.00026  | 3.92e+03 |     0 |
| oheencoded_Hotel_room      |   0.000257 | 3.92e+03 |     0 |

**Note**: values less than 1e-10 are rounded to zero.
