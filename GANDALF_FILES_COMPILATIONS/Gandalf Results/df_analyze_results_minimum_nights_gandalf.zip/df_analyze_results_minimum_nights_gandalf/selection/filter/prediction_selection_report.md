# Filter-Based Feature Selection Summary


## Selected Features

['number_of_reviews', 'availability_365', 'neighbourhood_labelencoded', 'latitude', 'price', 'private', 'cozy', 'oheencoded_Manhattan', 'oheencoded_Bronx', 'oheencoded_Shared_room', 'oheencoded_Staten_Island', 'hotel']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| number_of_reviews          | 2.481e-03 |
| availability_365           | 1.414e-02 |
| neighbourhood_labelencoded | 1.526e-02 |
| latitude                   | 1.536e-02 |
| price                      | 1.542e-02 |
| private                    | 1.548e-02 |
| cozy                       | 1.548e-02 |
| room                       | 1.551e-02 |
| luxury                     | 1.560e-02 |
| floor                      | 1.561e-02 |
| city                       | 1.563e-02 |
| in                         | 1.566e-02 |
| longitude                  | 1.571e-02 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| oheencoded_Manhattan       | 1.475e-02 |
| oheencoded_Bronx           | 1.496e-02 |
| oheencoded_Shared_room     | 1.497e-02 |
| oheencoded_Staten_Island   | 1.520e-02 |
| hotel                      | 1.530e-02 |
| oheencoded_Entire_home/apt | 1.545e-02 |
| oheencoded_Brooklyn        | 1.545e-02 |
| oheencoded_Queens          | 1.551e-02 |
| oheencoded_Hotel_room      | 1.553e-02 |
| oheencoded_Private_room    | 1.574e-02 |