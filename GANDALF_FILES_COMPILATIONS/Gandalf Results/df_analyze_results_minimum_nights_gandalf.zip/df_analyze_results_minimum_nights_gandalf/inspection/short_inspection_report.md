=================================================================================
                             Destructive Data Changes                            
=================================================================================
Removed Features
----------------

Ids
┄┄┄
name   More unique values than one half of number of non-NaN samples
Unnamed_0   All values including possible NaNs are unique
id          All values including possible NaNs are unique

Cardinality Coercions
---------------------
neighbourhood_labelencoded   Coerced to ordinal due to no decimal, feature name or undersampled levels
luxury                       Coerced to ordinal due to no decimal, feature name or undersampled levels
room                         Coerced to ordinal due to no decimal, feature name or undersampled levels
in                           Coerced to ordinal due to no decimal, feature name or undersampled levels
number_of_reviews            Coerced to ordinal due to no decimal, feature name or undersampled levels
cozy                         Coerced to ordinal due to no decimal, feature name or undersampled levels
private                      Coerced to ordinal due to no decimal, feature name or undersampled levels
city                         Coerced to ordinal due to no decimal, feature name or undersampled levels
floor                        Coerced to ordinal due to no decimal, feature name or undersampled levels
availability_365             Coerced to ordinal due to no decimal, feature name or undersampled levels

=================================================================================
                          Feature Cardinality Inferences                         
=================================================================================

Binary Features
---------------
oheencoded_Brooklyn          Two unique non-Nan values
oheencoded_Manhattan         Two unique non-Nan values
oheencoded_Private_room      Two unique non-Nan values
oheencoded_Staten_Island     Two unique non-Nan values
oheencoded_Queens            Two unique non-Nan values
oheencoded_Entire_home/apt   Two unique non-Nan values
hotel                        Two unique non-Nan values
oheencoded_Shared_room       Two unique non-Nan values
oheencoded_Bronx             Two unique non-Nan values
oheencoded_Hotel_room        Two unique non-Nan values

Numeric Features
----------------

Ordinals
┄┄┄┄┄┄┄┄
price                        Integers not starting at 0 or 1
neighbourhood_labelencoded   Coerced to ordinal due to no decimal, feature name or undersampled levels
luxury                       Coerced to ordinal due to no decimal, feature name or undersampled levels
room                         Coerced to ordinal due to no decimal, feature name or undersampled levels
in                           Coerced to ordinal due to no decimal, feature name or undersampled levels
number_of_reviews            Coerced to ordinal due to no decimal, feature name or undersampled levels
cozy                         Coerced to ordinal due to no decimal, feature name or undersampled levels
private                      Coerced to ordinal due to no decimal, feature name or undersampled levels
city                         Coerced to ordinal due to no decimal, feature name or undersampled levels
floor                        Coerced to ordinal due to no decimal, feature name or undersampled levels
availability_365             Coerced to ordinal due to no decimal, feature name or undersampled levels

Continuous
┄┄┄┄┄┄┄┄┄┄
longitude   All values are not integers and convert to float
latitude    All values are not integers and convert to float

