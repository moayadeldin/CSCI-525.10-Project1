# Continuous predictions

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| room                       | sgd-linear | 0.2238 |  7.695 | 0.08204 | -0.007626 |  0.007974  |
| availability_365           | sgd-linear | 0.2285 |  7.696 | 0.08419 | -0.02407  |  0.002225  |
| neighbourhood_labelencoded | sgd-linear | 0.2287 |  7.695 | 0.08362 | -0.02483  |  0.001366  |
| longitude                  | sgd-linear | 0.2285 |  7.696 | 0.08132 | -0.02741  |  0.000709  |
| private                    | sgd-linear | 0.2285 |  7.696 | 0.08275 | -0.0269   |  0.0002917 |
| cozy                       | sgd-linear | 0.2288 |  7.696 | 0.08351 | -0.02687  |  0.0002223 |
| in                         | sgd-linear | 0.2287 |  7.696 | 0.08314 | -0.02721  |  6.35e-05  |
| floor                      | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| room                       | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| cozy                       | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| in                         | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| private                    | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| city                       | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| latitude                   | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| luxury                     | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| neighbourhood_labelencoded | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| availability_365           | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| number_of_reviews          | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| minimum_nights             | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| longitude                  | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269  |  4.441e-17 |
| floor                      | sgd-linear | 0.2289 |  7.696 | 0.08321 | -0.02755  |  0         |
| city                       | sgd-linear | 0.2289 |  7.696 | 0.08283 | -0.02722  |  0         |
| luxury                     | sgd-linear | 0.2289 |  7.696 | 0.08301 | -0.02702  |  0         |
| latitude                   | sgd-linear | 0.2288 |  7.696 | 0.08283 | -0.02818  | -3.461e-05 |
| number_of_reviews          | sgd-linear | 0.2288 |  7.696 | 0.08251 | -0.02776  | -3.558e-05 |
| minimum_nights             | sgd-linear | 0.2288 |  7.696 | 0.08378 | -0.02777  | -0.0003458 |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |    mdae |         r2 |   var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|-----------:|----------:|
| oheencoded_Entire_home/apt | sgd-linear | 0.2069 |  7.697 | 0.05753 |  0.001663  | 0.02381   |
| oheencoded_Private_room    | sgd-linear | 0.2081 |  7.698 | 0.05883 | -1.074e-05 | 0.02239   |
| oheencoded_Manhattan       | sgd-linear | 0.2249 |  7.696 | 0.07904 | -0.0135    | 0.01354   |
| oheencoded_Brooklyn        | sgd-linear | 0.2283 |  7.695 | 0.08183 | -0.02406   | 0.003336  |
| oheencoded_Queens          | sgd-linear | 0.2274 |  7.694 | 0.08031 | -0.02388   | 0.002738  |
| oheencoded_Bronx           | sgd-linear | 0.2286 |  7.696 | 0.08273 | -0.02646   | 0.0003944 |
| oheencoded_Shared_room     | sgd-linear | 0.2288 |  7.695 | 0.08352 | -0.02658   | 0.0001072 |
| hotel                      | sgd-linear | 0.2288 |  7.696 | 0.08268 | -0.0274    | 3.201e-05 |
| oheencoded_Staten_Island   | sgd-linear | 0.2288 |  7.696 | 0.08286 | -0.02747   | 5.856e-06 |
| oheencoded_Hotel_room      | sgd-linear | 0.2288 |  7.696 | 0.08336 | -0.02685   | 7.499e-07 |
| oheencoded_Staten_Island   | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Shared_room     | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Queens          | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| hotel                      | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Private_room    | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Hotel_room      | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Entire_home/apt | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Brooklyn        | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Bronx           | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |
| oheencoded_Manhattan       | dummy      | 0.2291 |  7.699 | 0.07935 | -0.03269   | 4.441e-17 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
