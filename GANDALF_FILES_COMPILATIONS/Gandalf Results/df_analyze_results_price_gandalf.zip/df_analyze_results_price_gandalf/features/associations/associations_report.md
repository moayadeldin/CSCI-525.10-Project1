# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |       F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|--------:|---------:|
| neighbourhood_labelencoded |    0.179   |     0.0317  |    2.8e-05  |       0.126  |            0 |  17.6   | 2.8e-05  |
| longitude                  |    0.132   |    -0.0756  |    0        |      -0.38   |            0 | 100     | 0        |
| latitude                   |    0.107   |     0.0066  |    0.382    |       0.0857 |            0 |   0.763 | 0.382    |
| room                       |    0.102   |    -0.0506  |    0        |      -0.412  |            0 |  44.9   | 0        |
| availability_365           |    0.0708  |     0.0447  |    3.4e-09  |       0.154  |            0 |  35     | 3.4e-09  |
| number_of_reviews          |    0.0482  |    -0.00401 |    0.596    |       0.067  |            0 |   0.282 | 0.596    |
| minimum_nights             |    0.0459  |    -0.00856 |    0.258    |      -0.0955 |            0 |   1.28  | 0.258    |
| cozy                       |    0.0159  |    -0.0347  |    4.42e-06 |      -0.129  |            0 |  21.1   | 4.42e-06 |
| private                    |    0.0128  |    -0.0166  |    0.0286   |      -0.181  |            0 |   4.79  | 0.0286   |
| floor                      |    0.00923 |     0       |    0        |       0      |            0 |   0     | 1        |
| in                         |    0.00677 |    -0.0362  |    1.67e-06 |      -0.126  |            0 |  23     | 1.67e-06 |
| luxury                     |    0.00666 |     0       |    0        |       0      |            0 |   0     | 1        |
| city                       |    0.00593 |     0       |    0        |       0      |            0 |   0     | 1        |

# Categorical associations

|                            |   mut_info |          H |   H_p |
|:---------------------------|-----------:|-----------:|------:|
| oheencoded_Entire_home/apt |   0.263    |   9.53e+03 |     0 |
| oheencoded_Private_room    |   0.245    |   5.81e+03 |     0 |
| oheencoded_Manhattan       |   0.0442   |   6.08e+03 |     0 |
| oheencoded_Brooklyn        |   0.0177   |   5.97e+03 |     0 |
| oheencoded_Queens          |   0.0174   |   1.18e+03 |     0 |
| oheencoded_Shared_room     |   0.00754  | 388        |     0 |
| oheencoded_Bronx           |   0.00489  | 454        |     0 |
| oheencoded_Hotel_room      |   0.00396  | 330        |     0 |
| hotel                      |   0.00127  | 332        |     0 |
| oheencoded_Staten_Island   |   0.000639 | 357        |     0 |

**Note**: values less than 1e-10 are rounded to zero.
