# Filter-Based Feature Selection Summary


## Selected Features

['longitude', 'room', 'availability_365', 'in', 'cozy', 'neighbourhood_labelencoded', 'private', 'minimum_nights', 'latitude', 'number_of_reviews', 'luxury', 'floor', 'city', 'oheencoded_Entire_home/apt', 'oheencoded_Manhattan', 'oheencoded_Brooklyn', 'oheencoded_Private_room', 'oheencoded_Queens', 'oheencoded_Bronx', 'oheencoded_Shared_room', 'oheencoded_Staten_Island', 'hotel', 'oheencoded_Hotel_room']

## Selection Association Scores 

### Continuous Features (F-test: Higher = More important)

|                            |         F |
|:---------------------------|----------:|
| longitude                  | 1.005e+02 |
| room                       | 4.493e+01 |
| availability_365           | 3.498e+01 |
| in                         | 2.296e+01 |
| cozy                       | 2.109e+01 |
| neighbourhood_labelencoded | 1.756e+01 |
| private                    | 4.794e+00 |
| minimum_nights             | 1.280e+00 |
| latitude                   | 7.628e-01 |
| number_of_reviews          | 2.816e-01 |
| luxury                     | 0.000e+00 |
| floor                      | 0.000e+00 |
| city                       | 0.000e+00 |

### Categorical Features (Kruskal-Wallace H: Higher = More important)

|                            |         H |
|:---------------------------|----------:|
| oheencoded_Entire_home/apt | 9.533e+03 |
| oheencoded_Manhattan       | 6.081e+03 |
| oheencoded_Brooklyn        | 5.968e+03 |
| oheencoded_Private_room    | 5.808e+03 |
| oheencoded_Queens          | 1.178e+03 |
| oheencoded_Bronx           | 4.537e+02 |
| oheencoded_Shared_room     | 3.881e+02 |
| oheencoded_Staten_Island   | 3.574e+02 |
| hotel                      | 3.317e+02 |
| oheencoded_Hotel_room      | 3.299e+02 |