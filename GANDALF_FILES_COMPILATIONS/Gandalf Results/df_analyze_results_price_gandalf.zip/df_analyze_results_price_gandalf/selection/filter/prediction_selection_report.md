# Filter-Based Feature Selection Summary


## Selected Features

['room', 'availability_365', 'longitude', 'private', 'neighbourhood_labelencoded', 'in', 'cozy', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Manhattan', 'oheencoded_Queens', 'oheencoded_Brooklyn']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| room                       | -5.334e-03 |
| availability_365           | -6.468e-04 |
| longitude                  | -5.980e-04 |
| private                    | -5.558e-04 |
| neighbourhood_labelencoded | -4.202e-04 |
| in                         | -3.764e-04 |
| cozy                       | -3.301e-04 |
| number_of_reviews          | -3.174e-04 |
| latitude                   | -2.685e-04 |
| minimum_nights             | -2.672e-04 |
| floor                      | -2.249e-04 |
| luxury                     | -2.170e-04 |
| city                       | -2.126e-04 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| oheencoded_Entire_home/apt | -2.219e-02 |
| oheencoded_Private_room    | -2.097e-02 |
| oheencoded_Manhattan       | -4.191e-03 |
| oheencoded_Queens          | -1.716e-03 |
| oheencoded_Brooklyn        | -8.040e-04 |
| oheencoded_Bronx           | -4.772e-04 |
| oheencoded_Shared_room     | -3.516e-04 |
| hotel                      | -2.908e-04 |
| oheencoded_Hotel_room      | -2.719e-04 |
| oheencoded_Staten_Island   | -2.694e-04 |