# Final Model Performances

## Training set performance

model    selection    embed_selector      mae    mdae    msqe      r2    var-exp
-------  -----------  ----------------  -----  ------  ------  ------  ---------
gandalf  pred         none              0.144   0.061   0.991   0.006      0.013
gandalf  assoc        none              0.146   0.062   0.991   0.006      0.012
gandalf  none         none              0.151   0.072   0.973   0.024      0.024
dummy    assoc        none              0.163   0.081   1.006  -0.009      0.000
dummy    none         none              0.163   0.081   1.006  -0.009      0.000
dummy    pred         none              0.163   0.081   1.006  -0.009      0.000

## Holdout set performance

model    selection    embed_selector      mae    mdae    msqe      r2    var-exp
-------  -----------  ----------------  -----  ------  ------  ------  ---------
gandalf  pred         none              0.157   0.070   0.300   0.026      0.059
gandalf  none         none              0.163   0.083   0.288   0.065      0.067
gandalf  assoc        none              0.168   0.081   0.305   0.010      0.043
dummy    assoc        none              0.188   0.098   0.324  -0.053      0.000
dummy    none         none              0.188   0.098   0.324  -0.053      0.000
dummy    pred         none              0.188   0.098   0.324  -0.053      0.000

## 5-fold performance on holdout set

model    selection    embed_selector      mae    mdae    msqe      r2    var-exp
-------  -----------  ----------------  -----  ------  ------  ------  ---------
gandalf  none         none              0.152   0.075   0.285   0.072      0.078
gandalf  assoc        none              0.153   0.075   0.290   0.057      0.067
gandalf  pred         none              0.154   0.078   0.284   0.077      0.080
dummy    assoc        none              0.186   0.107   0.317  -0.032      0.000
dummy    none         none              0.186   0.107   0.317  -0.032      0.000
dummy    pred         none              0.186   0.107   0.317  -0.032      0.000

