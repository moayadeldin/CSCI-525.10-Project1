# Continuous predictions

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| room                       | sgd-linear | 0.1944 |  7.508 | 0.08082 |  0.02247  |  0.03843   |
| longitude                  | sgd-linear | 0.1982 |  7.498 | 0.08922 |  0.002547 |  0.01862   |
| availability_365           | sgd-linear | 0.1994 |  7.508 | 0.08415 | -0.03163  |  0.004081  |
| private                    | sgd-linear | 0.1993 |  7.508 | 0.08402 | -0.03288  |  0.001702  |
| in                         | sgd-linear | 0.1994 |  7.508 | 0.08368 | -0.03468  |  0.001479  |
| cozy                       | sgd-linear | 0.1994 |  7.508 | 0.08336 | -0.03407  |  0.001047  |
| neighbourhood_labelencoded | sgd-linear | 0.1993 |  7.507 | 0.08403 | -0.03382  |  0.001034  |
| minimum_nights             | sgd-linear | 0.1995 |  7.508 | 0.08431 | -0.03558  |  0.0004366 |
| luxury                     | sgd-linear | 0.1996 |  7.508 | 0.08435 | -0.0349   |  6.661e-17 |
| floor                      | sgd-linear | 0.1996 |  7.508 | 0.08389 | -0.03545  |  4.441e-17 |
| private                    | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| room                       | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| cozy                       | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| in                         | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| latitude                   | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| city                       | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| luxury                     | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| neighbourhood_labelencoded | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| availability_365           | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| minimum_nights             | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| longitude                  | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| floor                      | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624  |  2.22e-17  |
| city                       | sgd-linear | 0.1996 |  7.508 | 0.08434 | -0.0345   |  0         |
| latitude                   | sgd-linear | 0.1996 |  7.508 | 0.08443 | -0.03484  | -2.827e-05 |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |    mdae |         r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|-----------:|-----------:|
| oheencoded_Entire_home/apt | sgd-linear | 0.1778 |  7.51  | 0.05861 |  0.1056    |  0.131     |
| oheencoded_Private_room    | sgd-linear | 0.1787 |  7.51  | 0.05883 |  0.1046    |  0.1268    |
| oheencoded_Manhattan       | sgd-linear | 0.1957 |  7.51  | 0.08147 | -0.0004368 |  0.03048   |
| oheencoded_Brooklyn        | sgd-linear | 0.1986 |  7.505 | 0.08347 | -0.02171   |  0.01055   |
| oheencoded_Queens          | sgd-linear | 0.199  |  7.507 | 0.08456 | -0.03032   |  0.004042  |
| oheencoded_Bronx           | sgd-linear | 0.1994 |  7.507 | 0.08417 | -0.03263   |  0.00138   |
| oheencoded_Shared_room     | sgd-linear | 0.1996 |  7.508 | 0.08398 | -0.03408   |  0.0003646 |
| hotel                      | sgd-linear | 0.1995 |  7.508 | 0.08456 | -0.03721   |  0.0002695 |
| oheencoded_Hotel_room      | sgd-linear | 0.1996 |  7.508 | 0.08457 | -0.03551   |  8.206e-05 |
| hotel                      | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Staten_Island   | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Shared_room     | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Queens          | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Manhattan       | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Private_room    | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Hotel_room      | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Entire_home/apt | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Brooklyn        | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Bronx           | dummy      | 0.1995 |  7.51  | 0.08195 | -0.04624   |  2.22e-17  |
| oheencoded_Staten_Island   | sgd-linear | 0.1996 |  7.508 | 0.08468 | -0.03744   | -9.397e-05 |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
