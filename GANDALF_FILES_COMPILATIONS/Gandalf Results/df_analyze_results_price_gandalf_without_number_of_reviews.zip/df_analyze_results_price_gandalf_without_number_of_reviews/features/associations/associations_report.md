# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |       F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|--------:|---------:|
| neighbourhood_labelencoded |    0.172   |     0.0317  |    2.8e-05  |       0.126  |            0 |  17.6   | 2.8e-05  |
| longitude                  |    0.132   |    -0.0756  |    0        |      -0.38   |            0 | 100     | 0        |
| latitude                   |    0.109   |     0.0066  |    0.382    |       0.0857 |            0 |   0.763 | 0.382    |
| room                       |    0.096   |    -0.0506  |    0        |      -0.412  |            0 |  44.9   | 0        |
| availability_365           |    0.0674  |     0.0447  |    3.4e-09  |       0.154  |            0 |  35     | 3.4e-09  |
| minimum_nights             |    0.0559  |    -0.00856 |    0.258    |      -0.0955 |            0 |   1.28  | 0.258    |
| private                    |    0.0286  |    -0.0166  |    0.0286   |      -0.181  |            0 |   4.79  | 0.0286   |
| cozy                       |    0.0211  |    -0.0347  |    4.42e-06 |      -0.129  |            0 |  21.1   | 4.42e-06 |
| in                         |    0.00593 |    -0.0362  |    1.67e-06 |      -0.126  |            0 |  23     | 1.67e-06 |
| floor                      |    0.00152 |     0       |    0        |       0      |            0 |   0     | 1        |
| luxury                     |    0       |     0       |    0        |       0      |            0 |   0     | 1        |
| city                       |    0       |     0       |    0        |       0      |            0 |   0     | 1        |

# Categorical associations

|                            |   mut_info |          H |   H_p |
|:---------------------------|-----------:|-----------:|------:|
| oheencoded_Entire_home/apt |   0.267    |   9.53e+03 |     0 |
| oheencoded_Private_room    |   0.247    |   5.81e+03 |     0 |
| oheencoded_Manhattan       |   0.0445   |   6.08e+03 |     0 |
| oheencoded_Queens          |   0.0235   |   1.18e+03 |     0 |
| oheencoded_Brooklyn        |   0.0156   |   5.97e+03 |     0 |
| oheencoded_Shared_room     |   0.00649  | 388        |     0 |
| oheencoded_Hotel_room      |   0.0043   | 330        |     0 |
| oheencoded_Bronx           |   0.00224  | 454        |     0 |
| hotel                      |   0.00137  | 332        |     0 |
| oheencoded_Staten_Island   |   0.000327 | 357        |     0 |

**Note**: values less than 1e-10 are rounded to zero.
