# Filter-Based Feature Selection Summary


## Selected Features

['room', 'longitude', 'neighbourhood_labelencoded', 'private', 'in', 'cozy', 'oheencoded_Entire_home/apt', 'oheencoded_Private_room', 'oheencoded_Manhattan', 'oheencoded_Brooklyn', 'oheencoded_Queens']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| room                       | -5.141e-03 |
| longitude                  | -1.271e-03 |
| neighbourhood_labelencoded | -2.224e-04 |
| private                    | -2.206e-04 |
| in                         | -9.177e-05 |
| cozy                       | -9.072e-05 |
| availability_365           | -8.969e-05 |
| minimum_nights             | -2.613e-05 |
| floor                      |  6.565e-05 |
| luxury                     |  8.433e-05 |
| latitude                   |  1.047e-04 |
| city                       |  1.110e-04 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |        mae |
|:---------------------------|-----------:|
| oheencoded_Entire_home/apt | -2.169e-02 |
| oheencoded_Private_room    | -2.085e-02 |
| oheencoded_Manhattan       | -3.863e-03 |
| oheencoded_Brooklyn        | -9.411e-04 |
| oheencoded_Queens          | -4.807e-04 |
| oheencoded_Bronx           | -1.281e-04 |
| hotel                      | -1.062e-06 |
| oheencoded_Staten_Island   |  3.773e-05 |
| oheencoded_Hotel_room      |  5.537e-05 |
| oheencoded_Shared_room     |  5.619e-05 |