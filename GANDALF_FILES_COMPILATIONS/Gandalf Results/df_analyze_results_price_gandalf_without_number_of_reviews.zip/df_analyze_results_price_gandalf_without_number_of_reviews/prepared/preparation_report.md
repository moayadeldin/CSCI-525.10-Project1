# Data Preparation Summary

Task:                   Regression
Data original shape:    34977 samples × 27 features
Data final shape:       34977 samples × 22 features
Target feature:         price

Samples dropped due to NaN target: 0
Indicator variables added for continuous NaNs: 0

# Processing Times

| computation             |   runtime (ms) |
|:------------------------|---------------:|
| unify_nans              |           2036 |
| convert_categoricals    |              9 |
| inspect_target          |             78 |
| drop_target_nans        |            100 |
| clean_regression_target |             40 |
| drop_unusable           |           2701 |
| deflate_categoricals    |              3 |
| encode_categoricals     |           8796 |