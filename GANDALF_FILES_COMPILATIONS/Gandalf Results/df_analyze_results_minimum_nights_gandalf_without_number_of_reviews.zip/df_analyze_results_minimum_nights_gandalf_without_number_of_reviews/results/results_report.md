# Final Model Performances

## Training set performance

model    selection    embed_selector      mae    mdae    msqe       r2    var-exp
-------  -----------  ----------------  -----  ------  ------  -------  ---------
dummy    assoc        none              0.177   0.000   0.293   -0.021      0.000
dummy    none         none              0.177   0.000   0.293   -0.021      0.000
dummy    pred         none              0.177   0.000   0.293   -0.021      0.000
gandalf  assoc        none              0.187   0.066   0.280    0.026      0.026
gandalf  none         none              0.197   0.074   0.283    0.014      0.015
gandalf  pred         none              0.396   0.131  11.695  -39.746    -39.696

## Holdout set performance

model    selection    embed_selector      mae    mdae    msqe       r2    var-exp
-------  -----------  ----------------  -----  ------  ------  -------  ---------
gandalf  assoc        none              0.266   0.226   0.214   -0.030      0.004
gandalf  none         none              0.279   0.275   0.222   -0.068      0.010
dummy    assoc        none              0.294   0.414   0.247   -0.189      0.000
dummy    none         none              0.294   0.414   0.247   -0.189      0.000
dummy    pred         none              0.294   0.414   0.247   -0.189      0.000
gandalf  pred         none              0.424   0.298   5.446  -25.244    -25.072

## 5-fold performance on holdout set

model    selection    embed_selector      mae    mdae    msqe      r2    var-exp
-------  -----------  ----------------  -----  ------  ------  ------  ---------
gandalf  assoc        none              0.230   0.178   0.194   0.085      0.107
gandalf  none         none              0.236   0.188   0.198   0.067      0.089
dummy    assoc        none              0.275   0.186   0.246  -0.170     -0.000
dummy    none         none              0.275   0.186   0.246  -0.170     -0.000
dummy    pred         none              0.275   0.186   0.246  -0.170     -0.000
gandalf  pred         none              0.278   0.256   0.217  -0.064     -0.001

