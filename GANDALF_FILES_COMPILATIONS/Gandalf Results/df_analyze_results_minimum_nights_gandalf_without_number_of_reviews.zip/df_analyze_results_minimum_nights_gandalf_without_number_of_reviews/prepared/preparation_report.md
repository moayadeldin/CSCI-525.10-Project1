# Data Preparation Summary

Task:                   Regression
Data original shape:    34977 samples × 27 features
Data final shape:       34977 samples × 22 features
Target feature:         minimum_nights

Samples dropped due to NaN target: 0
Indicator variables added for continuous NaNs: 0

# Processing Times

| computation             |   runtime (ms) |
|:------------------------|---------------:|
| unify_nans              |           1975 |
| convert_categoricals    |             15 |
| inspect_target          |            104 |
| drop_target_nans        |            114 |
| clean_regression_target |             45 |
| drop_unusable           |           2176 |
| deflate_categoricals    |              5 |
| encode_categoricals     |           8158 |