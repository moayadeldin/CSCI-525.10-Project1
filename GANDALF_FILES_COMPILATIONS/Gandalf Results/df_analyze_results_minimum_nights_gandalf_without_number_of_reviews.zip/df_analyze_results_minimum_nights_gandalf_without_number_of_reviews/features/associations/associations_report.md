# Continuous associations

|                            |   mut_info |   pearson_r |   pearson_p |   spearman_r |   spearman_p |      F |      F_p |
|:---------------------------|-----------:|------------:|------------:|-------------:|-------------:|-------:|---------:|
| availability_365           |    0.115   |    -0.038   |    5.15e-07 |     -0.278   |      0       | 25.2   | 5.15e-07 |
| neighbourhood_labelencoded |    0.051   |     0.0325  |    1.72e-05 |      0.0737  |      0       | 18.5   | 1.72e-05 |
| longitude                  |    0.05    |    -0.066   |    0        |     -0.132   |      0       | 76.4   | 0        |
| latitude                   |    0.0447  |     0.0439  |    6.14e-09 |      0.106   |      0       | 33.8   | 6.14e-09 |
| price                      |    0.0426  |    -0.00875 |    0.247    |     -0.0954  |      0       |  1.34  | 0.247    |
| luxury                     |    0.00952 |     0       |    0        |      0       |      0       |  0     | 1        |
| private                    |    0.00622 |    -0.0347  |    4.33e-06 |     -0.0563  |      0       | 21.1   | 4.33e-06 |
| cozy                       |    0.00366 |    -0.0123  |    0.105    |     -0.00871 |      0.25    |  2.64  | 0.105    |
| room                       |    0.00053 |    -0.00513 |    0.497    |      0.0171  |      0.0238  |  0.461 | 0.497    |
| floor                      |    0       |     0       |    0        |      0       |      0       |  0     | 1        |
| city                       |    0       |     0       |    0        |      0       |      0       |  0     | 1        |
| in                         |    0       |    -0.0089  |    0.239    |      0.0235  |      0.00192 |  1.38  | 0.239    |

# Categorical associations

|                            |   mut_info |        H |   H_p |
|:---------------------------|-----------:|---------:|------:|
| oheencoded_Manhattan       |   0.00841  | 1.09e+04 |     0 |
| oheencoded_Brooklyn        |   0.00513  | 1.08e+04 |     0 |
| oheencoded_Queens          |   0.00445  | 5.45e+03 |     0 |
| oheencoded_Private_room    |   0.00359  | 1.06e+04 |     0 |
| oheencoded_Bronx           |   0.00148  | 4.2e+03  |     0 |
| oheencoded_Staten_Island   |   0.00143  | 3.98e+03 |     0 |
| oheencoded_Shared_room     |   0.000695 | 4.05e+03 |     0 |
| oheencoded_Hotel_room      |   1.77e-06 | 3.92e+03 |     0 |
| hotel                      |   0        | 3.92e+03 |     0 |
| oheencoded_Entire_home/apt |   0        | 1.41e+04 |     0 |

**Note**: values less than 1e-10 are rounded to zero.
