# Continuous predictions

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| availability_365           | sgd-linear | 0.217  | 0.6404 | 0.0347  | -0.009033 |  0.002876  |
| longitude                  | sgd-linear | 0.2181 | 0.6406 | 0.03698 | -0.0118   |  0.0003316 |
| private                    | sgd-linear | 0.2185 | 0.6408 | 0.03672 | -0.01195  |  0.0001243 |
| neighbourhood_labelencoded | sgd-linear | 0.2179 | 0.6408 | 0.03651 | -0.01253  |  0.0001065 |
| latitude                   | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| city                       | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| room                       | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| cozy                       | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| in                         | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| private                    | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| floor                      | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| luxury                     | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| neighbourhood_labelencoded | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| availability_365           | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| price                      | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| longitude                  | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| city                       | sgd-linear | 0.2183 | 0.6408 | 0.03659 | -0.01223  | -4.441e-17 |
| luxury                     | sgd-linear | 0.2183 | 0.6419 | 0.0359  | -0.01739  | -1.332e-16 |
| floor                      | sgd-linear | 0.2183 | 0.6409 | 0.0365  | -0.01252  | -1.332e-16 |
| room                       | sgd-linear | 0.2183 | 0.6409 | 0.03668 | -0.01241  | -3.25e-06  |
| cozy                       | sgd-linear | 0.2182 | 0.6408 | 0.0364  | -0.01245  | -8.874e-06 |
| in                         | sgd-linear | 0.2183 | 0.6408 | 0.03705 | -0.01233  | -4.134e-05 |
| price                      | sgd-linear | 0.2184 | 0.6409 | 0.037   | -0.01233  | -6.095e-05 |
| latitude                   | sgd-linear | 0.218  | 0.6409 | 0.03639 | -0.01298  | -0.0002168 |

# Categorical prediction:

| feature                    | model      |    mae |   msqe |    mdae |        r2 |    var-exp |
|:---------------------------|:-----------|-------:|-------:|--------:|----------:|-----------:|
| oheencoded_Manhattan       | sgd-linear | 0.2174 | 0.6394 | 0.04959 | -0.007325 |  0.004511  |
| oheencoded_Brooklyn        | sgd-linear | 0.2175 | 0.6401 | 0.0506  | -0.009841 |  0.002358  |
| oheencoded_Shared_room     | sgd-linear | 0.2182 | 0.6408 | 0.03681 | -0.01203  |  4.358e-05 |
| oheencoded_Hotel_room      | sgd-linear | 0.2183 | 0.6408 | 0.03663 | -0.01223  |  3.052e-05 |
| hotel                      | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Staten_Island   | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Shared_room     | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Queens          | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Private_room    | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Manhattan       | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Hotel_room      | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Entire_home/apt | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Brooklyn        | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| oheencoded_Bronx           | dummy      | 0.2029 | 0.643  | 0       | -0.03006  |  0         |
| hotel                      | sgd-linear | 0.2182 | 0.641  | 0.03649 | -0.0127   | -4.567e-05 |
| oheencoded_Private_room    | sgd-linear | 0.2184 | 0.6409 | 0.03826 | -0.01242  | -0.000153  |
| oheencoded_Queens          | sgd-linear | 0.2183 | 0.6408 | 0.03691 | -0.01227  | -0.0001812 |
| oheencoded_Entire_home/apt | sgd-linear | 0.2183 | 0.641  | 0.03885 | -0.01276  | -0.0002    |
| oheencoded_Bronx           | sgd-linear | 0.2182 | 0.6409 | 0.03658 | -0.01273  | -0.0002095 |
| oheencoded_Staten_Island   | sgd-linear | 0.2182 | 0.6409 | 0.03629 | -0.01227  | -0.000272  |

mae: Mean Absolute Error
msqe: Mean Squared Error
mdae: Median Absolute Error
r2: R-squared (coefficient of determination)
var-exp: Percent Variance Explained
