# Filter-Based Feature Selection Summary


## Selected Features

['longitude', 'latitude', 'availability_365', 'private', 'neighbourhood_labelencoded', 'cozy', 'in', 'price', 'room', 'luxury', 'floor', 'city', 'oheencoded_Entire_home/apt', 'oheencoded_Manhattan', 'oheencoded_Brooklyn', 'oheencoded_Private_room', 'oheencoded_Queens', 'oheencoded_Bronx', 'oheencoded_Shared_room', 'oheencoded_Staten_Island', 'hotel', 'oheencoded_Hotel_room']

## Selection Association Scores 

### Continuous Features (F-test: Higher = More important)

|                            |         F |
|:---------------------------|----------:|
| longitude                  | 7.643e+01 |
| latitude                   | 3.382e+01 |
| availability_365           | 2.523e+01 |
| private                    | 2.113e+01 |
| neighbourhood_labelencoded | 1.848e+01 |
| cozy                       | 2.636e+00 |
| in                         | 1.384e+00 |
| price                      | 1.338e+00 |
| room                       | 4.608e-01 |
| luxury                     | 0.000e+00 |
| floor                      | 0.000e+00 |
| city                       | 0.000e+00 |

### Categorical Features (Kruskal-Wallace H: Higher = More important)

|                            |         H |
|:---------------------------|----------:|
| oheencoded_Entire_home/apt | 1.406e+04 |
| oheencoded_Manhattan       | 1.090e+04 |
| oheencoded_Brooklyn        | 1.079e+04 |
| oheencoded_Private_room    | 1.064e+04 |
| oheencoded_Queens          | 5.453e+03 |
| oheencoded_Bronx           | 4.196e+03 |
| oheencoded_Shared_room     | 4.052e+03 |
| oheencoded_Staten_Island   | 3.981e+03 |
| hotel                      | 3.920e+03 |
| oheencoded_Hotel_room      | 3.915e+03 |