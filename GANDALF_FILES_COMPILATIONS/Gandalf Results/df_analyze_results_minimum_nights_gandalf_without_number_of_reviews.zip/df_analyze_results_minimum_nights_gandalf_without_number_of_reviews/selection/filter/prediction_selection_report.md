# Filter-Based Feature Selection Summary


## Selected Features

['availability_365', 'neighbourhood_labelencoded', 'latitude', 'longitude', 'cozy', 'floor', 'oheencoded_Manhattan', 'oheencoded_Brooklyn', 'oheencoded_Staten_Island', 'oheencoded_Shared_room', 'oheencoded_Bronx']

## Selection Prediction Scores 

### Continuous Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| availability_365           | 1.419e-02 |
| neighbourhood_labelencoded | 1.507e-02 |
| latitude                   | 1.518e-02 |
| longitude                  | 1.530e-02 |
| cozy                       | 1.535e-02 |
| floor                      | 1.543e-02 |
| city                       | 1.545e-02 |
| luxury                     | 1.548e-02 |
| room                       | 1.549e-02 |
| in                         | 1.549e-02 |
| price                      | 1.556e-02 |
| private                    | 1.560e-02 |

### Categorical Features (Mean Absolute Error: Lower = More important)

| feature                    |       mae |
|:---------------------------|----------:|
| oheencoded_Manhattan       | 1.454e-02 |
| oheencoded_Brooklyn        | 1.468e-02 |
| oheencoded_Staten_Island   | 1.534e-02 |
| oheencoded_Shared_room     | 1.536e-02 |
| oheencoded_Bronx           | 1.539e-02 |
| hotel                      | 1.540e-02 |
| oheencoded_Entire_home/apt | 1.543e-02 |
| oheencoded_Hotel_room      | 1.544e-02 |
| oheencoded_Queens          | 1.549e-02 |
| oheencoded_Private_room    | 1.553e-02 |